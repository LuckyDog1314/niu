package httpclient.httpclient;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.util.JSONPObject;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import net.sf.json.test.JSONAssert;
import net.sf.json.util.JSONBuilder;

public class ParameterJsonConversion {

	/**
	 * json字符串转化为属性
	 * 
	 * @param json
	 * @return
	 */
	public String jsonToParameter(String json) {
		ObjectMapper mapper = new ObjectMapper();
		JsonNode rootNode = null;
		try {
			rootNode = mapper.readTree(json);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String ss = paring(rootNode, null, "").replaceFirst("&", "");
		//System.out.println(ss);

		return ss;
	}

	public String paring(JsonNode jsonNode, String requestKey, String result) {
		Iterator<String> iterator = jsonNode.getFieldNames();

		while (iterator.hasNext()) {
			String key = iterator.next();
			JsonNode rootNode = jsonNode.get(key);

			String flag = "";
			if (requestKey != null) {
				flag = requestKey + "_" + key;
			} else {
				flag = key;
			}

			if (rootNode.isContainerNode()) {

				result = paring(rootNode, flag, result);

			} else {

				result += "&" + flag + "=" + rootNode.asText();

			}
		}

		return result;
	}

	/**
	 * 属性转化为字符串
	 * 
	 * @param parameter
	 * @return
	 */
	public String parameterToJson(String parameter) {

		String[] parameters = parameter.replaceAll("=", "_").split("&");

		return paring(parameters);
	}

	public Map<String, Object> map(String str, Object obj) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put(str, obj);
		return map;
	}

	public String paring(String[] parameters) {

		List<List<BeanUtils>> listList = new ArrayList<List<BeanUtils>>();

		for (int i = 0; i < parameters.length; i++) {
			String[] parameter = parameters[i].split("_");
			List<BeanUtils> list = new ArrayList<BeanUtils>();
			for (int m = 0; m < parameter.length - 1; m++) {
				list.add(m, null);
			}

			for (int j = parameter.length - 1; j > 0; j--) {
				int index = j - 1;
				String key = parameter[index];
				BeanUtils bu = new BeanUtils();

				bu.setKey(key);
				if (j == parameter.length - 1) {
					bu.setMap(map(key, parameter[j]));
				} else {
					bu.setMap(map(key, list.get(index + 1).getMap()));
				}
				list.remove(index);
				list.add(index, bu);
			}

			listList.add(list);

		}

		Map<String, List<String>> keyMap = new HashMap<String, List<String>>();
		List<BeanUtils> list0 = listList.get(0);
		List<String> keyList = new ArrayList<String>();
		for (int i = 0; i < list0.size(); i++) {
			keyList.add(i, list0.get(i).getKey());
		}
		keyMap.put(keyList.get(0), keyList);

		for (int a = 1; a < listList.size(); a++) {

			List<BeanUtils> list1 = listList.get(a);
			// int size = list0.size() < list1.size() ? list0.size() :
			// list1.size();
			int size = list1.size();
			for (int b = 0; b < size;) {
				String[] keyc = null;
				boolean flag = false;
				Set<String> set = keyMap.keySet();
				Iterator<String> iterator = set.iterator();
				while (iterator.hasNext()) {
					if (iterator.next().equals(list1.get(0).getKey())) {
						keyc = keyMap.get(list1.get(0).getKey()).get(b).split(",");
						for (int dd = 0; dd < keyc.length; dd++) {
							if (keyc[dd].equals(list1.get(b).getKey())) {
								flag = true;
								break;
							}
						}
						break;
					}
				}

				if (flag) {
					List<String> kkk = new ArrayList<String>();
					a(keyMap, b, list0, list1, kkk);
					break;
				} else {
					b(b, keyMap, list0, list1);
					break;
				}
			}

		}
		Map resultMap = listList.get(0).get(0).getMap();

		JSONObject jsonObject = JSONObject.fromObject(resultMap);

		// List<String> list=keyMap.get("head");
		// for(int i=0;i<list.size();i++){
		// System.out.println(list.get(i));
		// }
	//	System.out.println(jsonObject.toString());
		return jsonObject.toString();
	}

	public void a(Map<String, List<String>> map, int b, List<BeanUtils> list0, List<BeanUtils> list1,
			List<String> kkk) {

		if (b == list1.size()) {
			b = list1.size() - 1;
			setMap(list0, kkk, list1.get(b).getKey(), list1.get(b).getMap().get(list1.get(b).getKey()));

			List<String> keyList = map.get(list1.get(0).getKey());

			for (int i = b; i < list1.size(); i++) {
				if (i < keyList.size()) {
					String old = keyList.get(i);
					keyList.remove(i);
					keyList.add(i, old + "," + list1.get(i).getKey());
				} else {
					keyList.add(list1.get(i).getKey());
				}
			}
			map.put(list1.get(0).getKey(), keyList);
			return;
		}

		String[] keyc = map.get(list1.get(0).getKey()).get(b).split(",");
		boolean flag = false;

		for (int dd = 0; dd < keyc.length; dd++) {
			if (keyc[dd].equals(list1.get(b).getKey())) {
				kkk.add(b, keyc[dd]);
				flag = true;
				break;
			}
		}
		if (flag) {
			b++;
			a(map, b, list0, list1, kkk);
		} else {

			setMap(list0, kkk, list1.get(b).getKey(), list1.get(b).getMap().get(list1.get(b).getKey()));

			List<String> keyList = map.get(list1.get(0).getKey());

			for (int i = b; i < list1.size(); i++) {
				if (i < keyList.size()) {
					String old = keyList.get(i);
					keyList.remove(i);
					keyList.add(i, old + "," + list1.get(i).getKey());
				} else {
					keyList.add(list1.get(i).getKey());
				}
			}
			map.put(list1.get(0).getKey(), keyList);
		}
	}

	public void setMap(List<BeanUtils> list0, List<String> kkk, String key, Object value) {

		if (kkk.size() == 1) {
			((Map) list0.get(0).getMap().get(kkk.get(0))).put(key, value);
		}
		if (kkk.size() == 2) {
			((Map) ((Map) list0.get(0).getMap().get(kkk.get(0))).get(kkk.get(1))).put(key, value);
		}
		if (kkk.size() == 3) {
			((Map) ((Map) ((Map) list0.get(0).getMap().get(kkk.get(0))).get(kkk.get(1))).get(kkk.get(2))).put(key,
					value);
		}
		if (kkk.size() == 4) {
			((Map) ((Map) ((Map) ((Map) list0.get(0).getMap().get(kkk.get(0))).get(kkk.get(1))).get(kkk.get(2)))
					.get(kkk.get(3))).put(key, value);
		}
		if (kkk.size() == 5) {
			((Map) ((Map) ((Map) ((Map) ((Map) list0.get(0).getMap().get(kkk.get(0))).get(kkk.get(1))).get(kkk.get(2)))
					.get(kkk.get(3))).get(kkk.get(4))).put(key, value);
		}
	}

	public void b(int b, Map<String, List<String>> map, List<BeanUtils> list0, List<BeanUtils> list1) {

		list0.get(b).getMap().put(list1.get(b).getKey(), list1.get(b).getMap().get(list1.get(b).getKey()));

		List<String> keyList = new ArrayList<String>();
		for (int i = 0; i < list1.size(); i++) {
			if (i < keyList.size()) {
				String old = keyList.get(i);
				keyList.remove(i);
				keyList.add(i, old + "," + list1.get(i).getKey());
			} else {
				keyList.add(list1.get(i).getKey());
			}
		}
		map.put(list1.get(0).getKey(), keyList);

	}

	public boolean isJson(String str) {
		try {
			JSONObject.fromObject(str);
		} catch (Exception e) {
			return false;
		}

		return true;
	}

	public static void main(String[] args) {
		String json = "{\"head\":{\"bid\":\"BS011\",\"fid\":\"FN0009\",\"ver\":\"1.0\",\"au\":{\"acid\":\"123\",\"dety\":\"1\",\"deid\":\"获取登陆码测试\",\"acto\":\"123\"}}}";
		// json = "{\"head\":{\"bid\":{\"bid\":\"BS011\"}},\"dd\":\"tt\"}";
		json = "{\"head\": {\"bid\": \"123\",\"fid\": \"FN0004\",\"ver\": \"1.0\",\"au\": {\"lona\": \"ABC123456\",\"dety\": \"3\",\"deid\": \"862949029518557\",\"acto\": \"3035d150-7f9b-4486-9b00-e47dccf5638b\"}},\"body\": {\"com\": {\"senu\": \"20160705213754590\"},\"da\": {}}}";
		ParameterJsonConversion pj = new ParameterJsonConversion();
		System.out.println(pj.jsonToParameter(json));

		String parameter = "head_bid=BS011&head_fid=FN0009&head_ver=1.0&head_au_acid=123&head_au_dety=1&head_au_deid=获取登陆码测试&head_au_acto=123";
		// parameter = "aa_bb_cc=BS011&aa_dd=12&ff=GG";
		parameter = "a_b_c_d=1&a_c_d=2&c_a_a_dd_d_c=12&c_a_a_dd_d_d=999";
		parameter = "head_bid=BS101-NIU&head_fid=FN0004&head_ver=1.0&head_au_lona=ABC123456&head_au_dety=3&head_au_deid=862949029518557&head_au_acto=3035d150-7f9b-4486-9b00-e47dccf5638b&body_com_senu=20160705213754590";
		System.out.println(pj.parameterToJson(parameter));

		System.out.println(pj.isJson(json));
	}
}
