package http.client;

import java.util.HashMap;
import java.util.Map;

public class BeanUtils {
	
	private String key;
	private Map<String,Object> map=new HashMap<String, Object>();
	
	public void setKey(String key) {
		this.key = key;
	}
	public String getKey() {
		return key;
	}
	public void setMap(Map<String, Object> map) {
		this.map = map;
	}
	public Map<String, Object> getMap() {
		return map;
	}
}
