package file.upload;

public enum CD {
	
	A("8329"),
	B("3966"),
	C("4270"),
	D("9244"),
	E("9591"),
	F("7524"),
	G("954"),
	H("1904"),
	I("5287"),
	J("1676");


	
	private String code;

	private CD(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}
}
