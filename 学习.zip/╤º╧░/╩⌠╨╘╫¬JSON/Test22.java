package httpclient.httpclient;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import net.sf.json.JSONObject;
import net.sf.json.JsonConfig;

public class Test22 {

	public static void main(String[] args) {
		Test pj = new Test();
		String parameter = "head_bid=BS011&head_fid=FN0009&head_ver=1.0&head_au_acid=123&head_au_dety=1&head_au_deid=获取登陆码测试&head_au_acto=123";
		parameter = "a_b_c_d=1&a_c_d=2&c_a_a=12&c_a_c=999";
		pj.ParameterToJson(parameter);
	}

	public String ParameterToJson(String parameter) {

		String[] parameters = parameter.replaceAll("=", "_").split("&");

		paring(parameters);

		return null;
	}

	public Map<String, Object> map(String str, Object obj) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put(str, obj);
		return map;
	}

	public String paring(String[] parameters) {

		List<List<BeanUtils>> listList = new ArrayList<List<BeanUtils>>();

		for (int i = 0; i < parameters.length; i++) {
			String[] parameter = parameters[i].split("_");
			List<BeanUtils> list = new ArrayList<BeanUtils>();
			for (int m = 0; m < parameter.length - 1; m++) {
				list.add(m, null);
			}

			for (int j = parameter.length - 1; j > 0; j--) {
				int index = j - 1;
				String key = parameter[index];
				BeanUtils bu = new BeanUtils();

				bu.setKey(key);
				if (j == parameter.length - 1) {
					bu.setMap(map(key, parameter[j]));
				} else {
					bu.setMap(map(key, list.get(index + 1).getMap()));
				}
				list.remove(index);
				list.add(index, bu);
			}

			listList.add(list);

		}

		// for (int a = 0; a < listList.size(); a++) {
		// System.out.println(listList.get(a).get(0).getMap());
		// }

		List<String> keyList=new ArrayList<String>();
		List<BeanUtils> list0 = listList.get(0);
		for(int i=0;i<list0.size();i++){
			 keyList.add(i, list0.get(i).getKey());
		}
       
		for (int a = 1; a < listList.size(); a++) {
		
			List<BeanUtils> list1 = listList.get(a);
			int size = list0.size() < list1.size() ? list0.size() : list1.size();

			for (int b = 0; b < size; b++) {
				
				String[] keyc = keyList.get(b).split(",");
				boolean flag = false;
				for (int dd = 0; dd < keyc.length; dd++) {
					if (keyc[dd].equals(list1.get(b).getKey())) {
						flag = true;
						break;
					}
				}

				if (flag) {
					List<String> kkk = new ArrayList<String>();
					a(keyList,b, size, list0, list1, kkk);
					break;
				} else {
					b(b, keyList, list0, list1);
					break;
				}
			}
			
		}
		
		System.out.println(listList.get(0).get(0).getMap());
	for(int i=0;i<keyList.size();i++){
		System.out.println(keyList.get(i));
	}
		
		
		return null;
	}

	public void a(List<String> keyList,int b, int size, List<BeanUtils> list0, List<BeanUtils> list1, List<String> kkk) {
        
		if(b==size){
			b=list1.size()-1;
			setMap(list0,kkk, list1.get(b).getKey(), list1.get(b).getMap().get(list1.get(b).getKey()));
		    return;
		}
		String[] keyc = keyList.get(b).split(",");
		boolean flag = false;

		for (int dd = 0; dd < keyc.length; dd++) {
			if (keyc[dd].equals(list1.get(b).getKey())){
				kkk.add(b, keyc[dd]);
				flag = true;
				break;
			}
		}
		if (flag) {
			b++;
			a(keyList,b, size, list0, list1, kkk);
		} else {

			setMap(list0,kkk, list1.get(b).getKey(), list1.get(b).getMap().get(list1.get(b).getKey()));
			for(int i=b;i<list1.size();i++){
				if(i<keyList.size()){
				String old=keyList.get(i);
					keyList.remove(i);
				keyList.add(i,old + "," + list1.get(i).getKey());
				}else{
					keyList.add(list1.get(i).getKey());
				}
			
			}	
		}
	}

	public void setMap(List<BeanUtils> list0,List<String> kkk, String key, Object value) {
	System.out.println(kkk.size());
	System.out.println(kkk.get(0));
//		if (kkk.size() == 1) {
//			((Map) list0.get(0).getMap().get(kkk.get(0))).put(key, value);
//		}
//		if(kkk.size()==2){
//			((Map)((Map) list0.get(0).getMap().get(kkk.get(0))).get(kkk.get(1))).put(key, value);
//		}
//		if(kkk.size()==3){
//			((Map)((Map)((Map) list0.get(0).getMap().get(kkk.get(0))).get(kkk.get(1))).get(kkk.get(2))).put(key, value);
//		}
	}

	public void b(int b, List<String> keyList, List<BeanUtils> list0, List<BeanUtils> list1) {

		list0.get(b).getMap().put(list1.get(b).getKey(), list1.get(b).getMap().get(list1.get(b).getKey()));
		
		for(int i=0;i<list1.size();i++){
			if(i<keyList.size()){
			String old=keyList.get(i);
				keyList.remove(i);
			keyList.add(i,old + "," + list1.get(i).getKey());
			}else{
				keyList.add(list1.get(i).getKey());
			}
		
		}	
	}

}
