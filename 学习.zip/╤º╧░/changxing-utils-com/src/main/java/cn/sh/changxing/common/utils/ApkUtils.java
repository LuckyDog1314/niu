package cn.sh.changxing.common.utils;

import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.MessageDigest;
import java.util.Enumeration;
import java.util.Map;
import java.util.TreeMap;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * 解析APK工具
 * 
 * @author shengtengfei
 *
 */
public class ApkUtils {
	
	public static final String FILE_SIZE = "fileSize";
	public static final String MD5 = "md5";
	public static final String ICON_PATH = "iconPath";
	/**
	 * 解压 zip 文件(apk可以当成一个zip文件)，注意不能解压 rar 文件，只能解压 zip 文件 解压 rar 文件 会出现
	 * java.io.IOException: Negative seek offset 异常 create date:2009- 6- 9
	 * 
	 * @param file   apk 文件
	 *            java.io.IOException: Negative seek offset 异常
	 * @throws Exception
	 * @throws IOException
	 */
	public static Map<String, String> unZip(File file, String IconPath) throws Exception {
		Map<String, String> map = new TreeMap<>();
		ZipFile zipFile;

		// 计算文件大小
		String size = String.valueOf(file.length());
		map.put(FILE_SIZE, size);

		// 获取MD5码
		FileInputStream in = new FileInputStream(file);
		byte[] byteBuffer = new byte[2048];
		MessageDigest messageDigest = MessageDigest.getInstance(MD5);
		int numRead = 0;
		while ((numRead = in.read(byteBuffer)) != -1) {
			messageDigest.update(byteBuffer, 0, numRead);
		}
		in.close();
		byte[] md5 = messageDigest.digest();
		map.put(MD5, byteArrayToHex(md5));

		// 获取包名，版本号
		try {
			zipFile = new ZipFile(file);
			Enumeration enumeration = zipFile.entries();
			ZipEntry zipEntry = null;
			while (enumeration.hasMoreElements()) {
				
				zipEntry = (ZipEntry) enumeration.nextElement();
				if (zipEntry.isDirectory()) {

				} else {
					// 获取图标
					if (IconPath.equals(zipEntry.getName())) {
						try {
					        // 创建临时文件
					        File temp = File.createTempFile("icon", ".png");
					        map.put(ICON_PATH, temp.getAbsolutePath());
					        InputStream inputStream = zipFile.getInputStream(zipEntry);
					        input2TemporaryFile(inputStream, temp.getAbsolutePath());
					    } catch (IOException e) {
					    	e.printStackTrace();
					    }

					}
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return map;
	}

	// ///////////////////////////////// ILLEGAL STUFF, DONT LOOK :)
	public static float complexToFloat(int complex) {
		return (float) (complex & 0xFFFFFF00) * RADIX_MULTS[(complex >> 4) & 3];
	}

	private static final float RADIX_MULTS[] = { 0.00390625F, 3.051758E-005F, 1.192093E-007F, 4.656613E-010F };

	/**
	 * 获取APK解析值
	 * 
	 * @param file
	 * @return
	 */
	public static Map<String, String> getApkValue(File file, String iconPath) {
		Map<String, String> map = new TreeMap<>();
		try {
			map = ApkUtils.unZip(file, iconPath);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return map;
	}
	
	/**
	 * APK文件MD5校验码
	 * 
	 * @param byteArray
	 * @return APK文件MD5校验码
	 */
	public static String byteArrayToHex(byte[] byteArray) {
		char[] hexDigits = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
		char[] resultCharArray = new char[byteArray.length * 2];
		int index = 0;
		for (byte b : byteArray) {
			resultCharArray[index++] = hexDigits[b >>> 4 & 0xf];
			resultCharArray[index++] = hexDigits[b & 0xf];
		}
		return new String(resultCharArray);
	}
	/**
	 * 输入流转化为临时文件
	 * @param inputStream 二进制输入流
	 * @param filePath 临时文件路径
	 */
	public static void input2TemporaryFile(InputStream inputStream, String filePath){
		try {
			int length;
	        byte buffer[] = new byte[1024]; 
	        // 向临时文件中写入内容
	        DataOutputStream out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(filePath)));
	        while ((length = inputStream.read(buffer)) != -1){
				for(int j=0; j<length; j++){  
					out.write(buffer[j]);  
                }  
			}
	        out.close();
			
	    } catch (IOException e) {
	    }
	}
}
