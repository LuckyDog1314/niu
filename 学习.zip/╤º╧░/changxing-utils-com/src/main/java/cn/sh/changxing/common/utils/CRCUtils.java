package cn.sh.changxing.common.utils;

/**
 * CRC校验工具
 * 
 * @author meizhikang
 *
 */
public class CRCUtils {
	/**
	 * 获取需要校验文件的校验码
	 * 
	 * @param message 需要获取校验码的字节数组
	 * @return 十六进制的校验码字符串
	 */
	public static String getCRC16Code(byte[] message){
		// 预置的16位的CRC寄存器
		int CRCRegister = 0xFFFF;
		
		// 预置的多项式
		int Polynomial = 0xA001;

		// 移位
		int shift;
		
		if(message == null || message.length <= 0)
			return null;
		
		for(byte singleByte:message){
			// 把八位的二进制转化成16位的二进制数,高八位添加0,与CRC寄存器高八位1进行异或不会改变CRC高八位的值
			int hexByte = singleByte & 0x00FF;
			CRCRegister ^= hexByte;
			
            //对异或操作后的寄存器进行移位操作
			for(shift = 0; shift < 8; shift++){
				// 取得寄存器低位最后一位(与16进制的1进行与操作)
				int shiftByte = CRCRegister & 0x0001;
				CRCRegister >>= 1;
			
				if(shiftByte == 1)
					CRCRegister ^= Polynomial;
			}
		}
		
		// 格式化校验码,不足16位的前面补位
		String hexCrc16 = String.format("%04x", CRCRegister);
		
		return hexCrc16;
	}
}
