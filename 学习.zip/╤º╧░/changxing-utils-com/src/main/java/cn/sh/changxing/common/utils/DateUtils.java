/*
 * ChangXing TSP Platform 畅星TSP平台
 * Copyright (c) 2014- ChangXing, http://changxing.sh.cn
 */
package cn.sh.changxing.common.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/**
 * 日期工具类定义
 * 
 * @author ChenJun
 * @version 1.0
 */
public class DateUtils {

    /**
     * 返回当前系统时间。
     * 
     * @return 当前系统时间
     */
    public static Date getSysDate() {
        Calendar c = Calendar.getInstance();
        return c.getTime();
    }

    /**
     * 返回当前系统UTC时间
     * 
     * @return 当前系统UTC时间
     */
    public static Date getSysUTCDate() {
        // 1、取得本地时间
        final Calendar cal = Calendar.getInstance();
        // 2、取得时间偏移量
        final int zoneOffset = cal.get(Calendar.ZONE_OFFSET);
        // 3、取得夏令时差
        final int dstOffset = cal.get(Calendar.DST_OFFSET);
        // 4、从本地时间里扣除这些差量，即可以取得UTC时间
        cal.add(Calendar.MILLISECOND, -(zoneOffset + dstOffset));
        return cal.getTime();
    }
    
    /**
     * 把本地时间转化成UTC时间
     */
    public static Date GMTDate2UTCDate(Date GMTDate){
    	TimeZone gmtZone = TimeZone.getTimeZone("GMT");
    	TimeZone utcZone = TimeZone.getTimeZone("UTC");
    	Long targetTime = GMTDate.getTime() - gmtZone.getRawOffset() + utcZone.getRawOffset();
    	return new Date(targetTime);
    }
    
    /**
     * 把UTC时间转化成本地时间
     */
    public static Date UTCDate2GMTDate(Date UTCDate){
    	TimeZone gmtZone = TimeZone.getTimeZone("UTC");
    	TimeZone utcZone = TimeZone.getTimeZone("GMT");
    	Long targetTime = UTCDate.getTime() - utcZone.getRawOffset() + gmtZone.getRawOffset();
    	return new Date(targetTime);
    }

    /**
     * 返回加减后的日期。
     * 
     * @param date 计算对象的日期
     * @param year 年
     * @param month 月
     * @param day 日
     * @return 加算后的日期
     */
    public static Date addDate(Date date, int year, int month, int day) {
        if (date == null) {
            return null;
        }
        Calendar cal = date2calendar(date);
        cal.add(Calendar.YEAR, year);
        cal.add(Calendar.MONTH, month);
        cal.add(Calendar.DATE, day);
        // 时分秒设为0
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        return cal.getTime();
    }
    /**
     * 
     * addDate:在制定时间上增加 时，分，秒，毫秒
     *
     * @author liliang
     * @param date 需要增加的时间
     * @param hour 加小时
     * @param minute 分钟
     * @param second 秒钟
     * @param millisecond 毫秒
     * @return
     */
    public static Date addDate(Date date,int hour,int minute,int second,int millisecond){
        int milsend = 0;
        if(hour != 0){
            milsend = hour * 60 * 60 *1000; 
        }
        if(minute != 0){
            milsend = milsend + minute * 60 * 1000;
        }
        if(second != 0){
            
            milsend = milsend + second * 1000;
        }
        if(millisecond != 0){
            milsend = milsend + millisecond;
        }
        String time = DateUtils.Long2String("yyyy-MM-dd HH:mm:ss", date.getTime()+milsend);
        
        return String2Date("yyyy-MM-dd HH:mm:ss", time);
    }

    /**
     * 类型变换（Date->Calendar）
     * 
     * @param date 变换对象日期
     * @return 变换后日期
     */
    public static Calendar date2calendar(Date date) {
        if (date == null) {
            return null;
        }
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        return c;
    }

    /**
     * 将日期对象格式化成字符串
     * 
     * @param format 格式化样式字符串
     * @param date 格式化对象日期
     * @return 格式化日期字符串
     */
    public static String Date2String(String format, Date date) {
        if (date == null) {
            return null;
        }

        SimpleDateFormat formatter = new SimpleDateFormat(format);
        return formatter.format(date);
    }

    /**
     * 从当前服务器取得24小时制单位到秒的时间 格式为：yyyyMMddHHmmss，<br>
     * 例,2015年9月6日13点58分2秒返回：20150906135802
     * 
     * @return 系统当前时间的字符串
     */
    public static String getSysTimeYmdhhmiss() {
        return Date2String("yyyyMMddHHmmss", getSysDate());
    }
    
    /**
     * 从当前服务器取得24小时制单位到秒的时间 格式为：yyyyMMddHHmmss，<br>
     * 例,2015年9月6日13点58分2秒返回：20150906 13:58:02
     * 
     * @return 系统当前时间的字符串
     */
    public static String getSysTimeYmdhhmmss() {
        return Date2String("yyyyMMdd HH:mm:ss", getSysDate());
    }

    /**
     * 从当前服务器取得24小时制单位到秒的UTC时间 格式为：yyyyMMddHHmmss，<br>
     * 例,2015年9月6日13点58分2秒返回：20150906135802
     * 
     * @return 系统当前UTC时间的字符串
     */
    public static String getSysUTCTimeYmdhhmiss() {
        return Date2String("yyyyMMddHHmmss", getSysUTCDate());
    }

    /**
     * 从当前服务器取得24小时制单位到分的时间 格式为：yyyyMMddHHmm，<br>
     * 例,2015年9月6日13点58分返回：201509061358
     * 
     * @return 系统当前时间的字符串
     */
    public static String getSysTimeYmdhhmm() {
        return Date2String("yyyyMMddHHmm", getSysDate());
    }

    /**
     * 从当前服务器取得24小时制单位到分的时间 格式为：yyyy-MM-dd HH:mm，<br>
     * 例,2015年9月6日13点58分返回：2015-09-06 13:58
     * 
     * @return 系统当前时间的字符串
     */
    public static String getSysTimeAsNormal() {
        return Date2String("yyyy-MM-dd HH:mm", getSysDate());
    }

    /**
     * 从当前服务器取得的时间 格式为：yyyyMMdd，<br>
     * 例,2015年9月6日返回：20150906
     * 
     * @return 系统当前时间的字符串
     */
    public static String getSysTimeYmd() {
        return Date2String("yyyyMMdd", getSysDate());
    }

    /**
     * 从当前服务器取得24小时制单位到毫秒的时间 格式为：yyyyMMddHHmmssSSS，<br>
     * 例,2015年9月6日13点58分2秒355毫秒返回：20150906135802355
     * 
     * @return 系统当前时间的字符串
     */
    public static String getSysTimeYmdhhmissSSS() {
        return Date2String("yyyyMMddHHmmssSSS", getSysDate());
    }

    /**
     * 将字符串类型日期格式化成日期
     * 
     * @param format 格式化样式字符串
     * @param dateTime 格式化对象日期字符串
     * @return 格式化日期
     */
    public static Date String2Date(String format, String dateTime) {
        if (dateTime == null || "".equals(dateTime)) {
            return null;
        }

        // 定义日期解析格式
        SimpleDateFormat formatter = new SimpleDateFormat(format);

        Date date = null;
        try {
            date = formatter.parse(dateTime);
        } catch (ParseException e) {
            return null;
        }

        return date;
    }

    /**
     * 返回当前系统年度。
     * 
     * @return 系统当前年度
     */
    public static int getSysYear() {
        Calendar c = Calendar.getInstance();
        return c.get(Calendar.YEAR);
    }

    /**
     * 毫秒时间转化成字符形式
     * 
     * @param format 字符格式
     * @param dateTime 毫秒时间
     * @return 格式化日期
     */
    public static String Long2String(String format, long dateTime) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(dateTime);
        SimpleDateFormat formatter = new SimpleDateFormat(format);
        return formatter.format(c.getTime());
    }

    /**
     * 计算时间差
     * 
     * @param startTime 开始时间
     * @param endTime 结束时间
     * @return 时间差字符
     */
    public static String difTime(long startTime, long endTime) {
        long dif = endTime - startTime;
        long day = dif / (24 * 60 * 60 * 1000);
        long hour = (dif / (60 * 60 * 1000) - day * 24);
        long min = ((dif / (60 * 1000)) - day * 24 * 60 - hour * 60);
        long s = (dif / 1000 - day * 24 * 60 * 60 - hour * 60 * 60 - min * 60);  
        long sss = (dif - day * 24 * 60 * 60* 1000 - hour * 60 * 60 - min * 60 - s * 1000);
        StringBuilder sb = new StringBuilder();
        if (day != 0) {
            sb.append(day).append("天 ");
        }
        if (hour != 0 || sb.length() != 0) {
            sb.append(hour).append("小时");
        }
        if (min != 0 || sb.length() != 0) {
            sb.append(min).append("分钟");
        }
        if (s != 0 || sb.length() != 0) {
            sb.append(s).append("秒");
        }
        if (sss != 0 || sb.length() != 0) {
            sb.append(sss).append("毫秒");
        }
        if (sb.length() == 0) {
            sb.append("0毫秒");
        }
        return sb.toString();
    }
    /**
     * 获取一个月的月初凌晨
     * @param date
     * @return
     */
    public static Date getTheMonth(Date date){
    	if(date==null){
    		return null;
    	}
        Calendar cal = date2calendar(date);
		cal.set(Calendar.DAY_OF_MONTH, cal.getActualMinimum(Calendar.DAY_OF_MONTH));
		// 时分秒毫秒设为0
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTime();
    }
    /**
     * 获取下个月的月初凌晨（即月末）
     * @param date
     * @return
     */
    public static Date getTheNextMonth(Date date){
    	if(date==null){
    		return null;
    	}
        Calendar cal = date2calendar(date);
		cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
		 //日期加一天
        cal.add(Calendar.DATE, 1);
		// 时分秒毫秒设为0
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTime();
    }
    /**
     * 获取当前日期的开始时间（凌晨）
     * @param date
     * @return
     */
    public static Date getTheDay(Date date){
    	if(date==null){
    		return null;
    	}
        Calendar cal = date2calendar(date);
        // 时分秒毫秒设为0
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTime();
    }
    /**
     * 获取当前日期的结束时间（第二天的凌晨）
     * @param date
     * @return
     */
    public static Date getTheNextDay(Date date){
    	if(date==null){
    		return null;
    	}
        Calendar cal = date2calendar(date);
        //日期加一天
        cal.add(Calendar.DATE, 1);
        // 时分秒毫秒设为0
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTime();
    }
    /**
     * 获取昨天的开始时间（昨天的凌晨）
     * @param date
     * @return
     */
    public static Date getTheBeforeDay(Date date){
    	if(date==null){
    		return null;
    	}
        Calendar cal = date2calendar(date);
        //日期加一天
        cal.add(Calendar.DATE, -1);
        // 时分秒设为0
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        return cal.getTime();
    }
    /**
     * 获取本周的开始时间（本周周日的凌晨）
     * @return
     */
    public static Date getTheWeek(){
    	Calendar weekCalendar = Calendar.getInstance();
    	//设置时分秒为0
		weekCalendar.set(Calendar.HOUR_OF_DAY, 0);
		weekCalendar.set(Calendar.MINUTE, 0);
		weekCalendar.set(Calendar.SECOND, 0);
		//周日
		weekCalendar.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);
        return weekCalendar.getTime();
    }
    /**
     * 获取本周的结束时间（下周周日的凌晨）
     * @return
     */
    public static Date getTheNextWeek(){
    	Calendar weekCalendar = Calendar.getInstance();
    	//设置时分秒为0
		weekCalendar.set(Calendar.HOUR_OF_DAY, 0);
		weekCalendar.set(Calendar.MINUTE, 0);
		weekCalendar.set(Calendar.SECOND, 0);
		//周六
		weekCalendar.set(Calendar.DAY_OF_WEEK, Calendar.SATURDAY);
		//下周周日
        weekCalendar.add(Calendar.DATE, 1);
        return weekCalendar.getTime();
    }
    /**
     * CST转String
     * @param cst
     * @param format
     * @return
     */
    public static String CST2String(String cst,String format){
    	if(cst == null||"".equals(cst)){
    		return null;
    	}
    	
    	SimpleDateFormat sdf = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy", Locale.US);
		Date date = null;
		try {
			date = sdf.parse(cst);
		} catch (ParseException e) {
			return null;
		}
		String str = new SimpleDateFormat(format).format(date);
    	return str;
    }
    
    /**
     * 比较入力参数和当前系统时间的大小
     * 比当前时间大,返回true
     * @param date
     * @return
     */
    public static boolean compareTime(Date date){
    	if(date!=null){
    		if(date.getTime()>new Date().getTime()){
    			return true;
    		}
    	}
    	return false;
    } 
    
    
    
    /**
     * 类　　名: DateStyle <br/>
     * 功能描述: 时间格式化字符串枚举类。 <br/>
     *
     * @author WANGZHENG
     * @version 1.0
     */
    public enum DateStyle {
        
        MMDD("MMdd"),
        YYYYMM("yyyyMM"),
        YYYYMMDD("yyyyMMdd"),
        MMDD_HHMM("MMdd HH:mm"),
        MMDD_HHMMSS("MMdd HHmmss"),
        YYYYMMDD_HHMM("yyyyMMdd HHmm"),
        YYYYMMDD_HHMMSS("yyyyMMdd HHmmss"),
        YYYYMMDDHHMMSS("yyyyMMddHHmmss"),
        YYYYMMDD_HH_MM_SS("yyyyMMdd HH:mm:ss"),
        
        MM_DD("MM-dd"),
        YYYY_MM("yyyy-MM"),
        YYYY_MM_DD("yyyy-MM-dd"),
        MM_DD_HH_MM("MM-dd HH:mm"),
        MM_DD_HH_MM_SS("MM-dd HH:mm:ss"),
        YYYY_MM_DD_HH("yyyy-MM-dd HH"),
        YYYY_MM_DD_HH_MM("yyyy-MM-dd HH:mm"),
        YYYY_MM_DD_HH_MM_SS("yyyy-MM-dd HH:mm:ss"),
        
        MM_DD_EN("MM/dd"),
        YYYY_MM_EN("yyyy/MM"),
        YYYY_MM_DD_EN("yyyy/MM/dd"),
        MM_DD_HH_MM_EN("MM/dd HH:mm"),
        MM_DD_HH_MM_SS_EN("MM/dd HH:mm:ss"),
        YYYY_MM_DD_HH_MM_EN("yyyy/MM/dd HH:mm"),
        YYYY_MM_DD_HH_MM_SS_EN("yyyy/MM/dd HH:mm:ss"),
        
        MM_DD_CN("MM月dd日"),
        YYYY_MM_CN("yyyy年MM月"),
        YYYY_MM_DD_CN("yyyy年MM月dd日"),
        MM_DD_HH_MM_CN("MM月dd日 HH:mm"),
        MM_DD_HH_MM_SS_CN("MM月dd日 HH:mm:ss"),
        YYYY_MM_DD_HH_MM_CN("yyyy年MM月dd日 HH:mm"),
        YYYY_MM_DD_HH_MM_SS_CN("yyyy年MM月dd日 HH:mm:ss"),
        
        HH_MM("HH:mm"),
        HH_MM_SS("HH:mm:ss"),
        
    	//2004-12-31T16:00:00Z
    	YYYY_MM_DDTHH_MM_SSZ("yyyy-MM-dd'T'HH:mm:ss.Z");
    	
        private String value;
        
        DateStyle(String value) {
            this.value = value;
        }
        
        public String getValue() {
            return value;
        }
    }
}
