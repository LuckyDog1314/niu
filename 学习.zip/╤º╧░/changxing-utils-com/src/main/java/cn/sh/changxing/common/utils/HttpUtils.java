package cn.sh.changxing.common.utils;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.map.ObjectMapper;

/**
 * 简单的封装了http请求，实现get和post方法
 * 
 * @author meizhikang
 *
 */
public class HttpUtils {

	public static byte[] doGet(String url, Map<String, String> params) {
		byte[] result = null;
		CloseableHttpClient httpClient = HttpClients.createDefault();
		String request = url + splitJoinGetRequest(params);
		System.out.println("DO GET,REQUEST URL:" + request);
		HttpGet getRequest = new HttpGet(request);
		try {
			CloseableHttpResponse response = httpClient.execute(getRequest);
			if (response != null)
				result = EntityUtils.toByteArray(response.getEntity());
		} catch (Exception e) {
			System.err.println("doGet error,CausedBy:" + e);
		} finally {
			try {
				httpClient.close();
			} catch (IOException e) {

			}
		}
		return result;
	}

	public static byte[] doPost(String url, List<NameValuePair> params) {
		byte[] result = null;
		CloseableHttpClient httpClient = HttpClients.createDefault();
		HttpPost postRequest = new HttpPost(url);
		try {
			UrlEncodedFormEntity formatParams = new UrlEncodedFormEntity(params, "UTF-8");
			postRequest.setEntity(formatParams);
			CloseableHttpResponse response = httpClient.execute(postRequest);
			if (response != null)
				result = EntityUtils.toByteArray(response.getEntity());
		} catch (Exception e) {
			System.err.println("doPost error,CausedBy:" + e);
		} finally {
			try {
				httpClient.close();
			} catch (IOException e) {

			}
		}
		return result;
	}

	private static String splitJoinGetRequest(Map<String, String> requestParams) {
		StringBuilder sbuilder = new StringBuilder("?");
		Iterator<Map.Entry<String, String>> it = requestParams.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry<String, String> entry = it.next();
			sbuilder.append("&" + entry.getKey() + "=");
			sbuilder.append(entry.getValue());
		}
		return sbuilder.toString();
	}
	
	public static String sendFile(File files){
		String id = "";
		CloseableHttpClient httpClient = HttpClients.createDefault();
		try {
			HttpPost httpPost = new HttpPost("http://192.168.30.225:10180/ws/file/upload/single");
			FileBody file = new FileBody(files);
			StringBody name = new StringBody("portrait_id", ContentType.TEXT_PLAIN);
			StringBody type = new StringBody("application/octet-stream", ContentType.TEXT_PLAIN);

			HttpEntity reqEntity = MultipartEntityBuilder.create().addPart("file", file).addPart("name", name)
					.addPart("type", type).build();

			httpPost.setEntity(reqEntity);

			System.out.println("executing request " + httpPost.getRequestLine());
			System.out.println("executing request " + httpPost.getFirstHeader("Content-type"));

			CloseableHttpResponse response = httpClient.execute(httpPost);

			try {
				System.out.println("----------------------------------------");
				System.out.println(response.getStatusLine());
				HttpEntity resEntity = response.getEntity();
				if (resEntity != null) {
					String strEntity = EntityUtils.toString(resEntity, "UTF-8");
					 ObjectMapper mapper = new ObjectMapper();
					 JsonNode rootNode = mapper.readTree(strEntity);
					 id = rootNode.path("id").asText();
					System.out.println("Response content length: " + resEntity.getContentLength());
				}
				EntityUtils.consume(resEntity);
			} finally {
				response.close();
			}
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				httpClient.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return id;
	}
}
