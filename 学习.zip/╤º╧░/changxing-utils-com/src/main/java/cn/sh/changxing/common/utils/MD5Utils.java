/*
 * ChangXing TSP Platform 畅星TSP平台
 * Copyright (c) 2014- ChangXing, http://changxing.sh.cn
 */
package cn.sh.changxing.common.utils;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * MD5加密工具类定义
 * 
 * @author ChenJun
 * @version 1.0
 */
public class MD5Utils {
	/** UTF8编码 */
    public static final String CHARSET_UTF8 = "UTF-8";

    /**
     * 取得32位MD5加密密文
     * 
     * @param plainText 加密对象字符串
     * @return 32位MD5加密密文
     * @throws NoSuchAlgorithmException
     * @throws UnsupportedEncodingException
     */
    public static String getMd5_32(String plainText) throws UnsupportedEncodingException, NoSuchAlgorithmException {
        if (plainText == null) {
            return "";
        }

        return create(plainText.getBytes(CHARSET_UTF8));
    }

    /**
     * 取得32位MD5加密密文
     * 
     * @param plainText 加密对象字节数组
     * @return 32位MD5加密密文
     * @throws NoSuchAlgorithmException
     */
    public static String getMd5_32(byte[] plainText) throws NoSuchAlgorithmException {
        return create(plainText);
    }

    /**
     * 取得16位MD5加密
     * 
     * @param plainText 加密对象字符串
     * @return 16位MD5加密密文
     * @throws NoSuchAlgorithmException
     * @throws UnsupportedEncodingException
     */
    public static String getMd5_16(String plainText) throws UnsupportedEncodingException, NoSuchAlgorithmException {
        if (plainText == null) {
            return "";
        }
        return create(plainText.getBytes(CHARSET_UTF8)).substring(8, 24);
    }

    /**
     * 取得16位MD5加密
     * 
     * @param plainText 加密对象字节数组
     * @return 16位MD5加密密文
     * @throws NoSuchAlgorithmException
     */
    public static String getMd5_16(byte[] plainText) throws NoSuchAlgorithmException {
        if (plainText == null) {
            return "";
        }

        return create(plainText).substring(8, 24);
    }

    /**
     * 生成32位MD5密文
     * 
     * @param plainText 加密对象字节数组
     * @return 32位MD5密文
     * @throws NoSuchAlgorithmException
     */
    private static String create(byte[] plainText) throws NoSuchAlgorithmException {
        MessageDigest md = null;
        // 取得MD5的加密算法对象
        md = MessageDigest.getInstance("MD5");

        // MD5加密
        md.update(plainText);
        byte b[] = md.digest();

        int i;
        StringBuffer buf = new StringBuffer("");
        for (int offset = 0; offset < b.length; offset++) {
            i = b[offset];
            if (i < 0) {
                i += 256;
            }
            if (i < 16) {
                buf.append("0");
            }
            buf.append(Integer.toHexString(i));
        }
        return buf.toString();
    }
    
    /**
     * 
     * GetMD5Code:(处理概要). <br/>
     * 返回md5加密的byte[]
     * 
     * @param strObj
     * @return
     */
    public static byte[] GetMD5Code(String strObj) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            return md.digest(strObj.getBytes("UTF-8"));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
