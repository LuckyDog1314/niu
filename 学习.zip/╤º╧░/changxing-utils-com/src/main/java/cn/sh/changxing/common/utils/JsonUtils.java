/*
 * ChangXing TSP Platform 畅星TSP平台
 * Copyright (c) 2014- ChangXing, http://changxing.sh.cn
 */
package cn.sh.changxing.common.utils;

import java.io.IOException;
import java.io.InputStream;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.DeserializationConfig;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.SerializationConfig.Feature;
import org.codehaus.jackson.type.TypeReference;

/**
 * Json字符串序列化/反序列化工具类定义
 * 
 * @author ChenJun
 * @version 1.0
 */
public class JsonUtils {

    /**
     * 将对象转化为Json字符串
     * 
     * @param bean 转换对象
     * @return Json字符串
     * @throws JsonGenerationException
     * @throws JsonMappingException
     * @throws IOException
     */
    public static <T> String toJson(T bean) throws JsonGenerationException, JsonMappingException, IOException {
        if (bean == null) {
            return "";
        }

        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(Feature.FAIL_ON_EMPTY_BEANS, false);
        String result = mapper.writeValueAsString(bean);
        return result;
    }

    /**
     * 将Json字符串转化为对象
     * 
     * @param jsonStr Json字符串
     * @return 转化后对象
     * @throws JsonParseException
     * @throws JsonMappingException
     * @throws IOException
     */
    public static <T> T fromJson(String jsonStr, TypeReference<T> type) throws JsonParseException,
            JsonMappingException, IOException
    {
        if (jsonStr == null || "".equals(jsonStr)) {
            return null;
        }

        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationConfig.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
        mapper.configure(DeserializationConfig.Feature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true);
        mapper.configure(DeserializationConfig.Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        T bean = mapper.readValue(jsonStr, type);
        return bean;
    }

    /**
     * 将Json字符串转化为对象
     * 
     * @param is Json字符流
     * @param clazz 转化后的Bean类
     * @return 转化后对象
     * @throws JsonParseException
     * @throws JsonMappingException
     * @throws IOException
     */
    public static <T> T fromJson(InputStream is, Class<T> clazz) throws JsonParseException, JsonMappingException,
            IOException
    {
        if (is == null || is.available() == 0) {
            return null;
        }

        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationConfig.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
        mapper.configure(DeserializationConfig.Feature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true);
        mapper.configure(DeserializationConfig.Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        T bean = mapper.readValue(is, clazz);
        return bean;
    }
  
    /**
     * 把json字符串装化为JsonNode
     * 用于解析访问信源返回的数据
     * @param jsonString
     * @return
     */
    public static JsonNode fromJsonNode(String jsonString){
    	if(jsonString==null){
    		return null;
    	}
    	ObjectMapper mapper = new ObjectMapper();
    	JsonNode jsonNode=null;
    	try {
			jsonNode=mapper.readTree(jsonString);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	return jsonNode;
    }
    
}
