package xml.xml;

import java.io.File;
import java.util.Iterator;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.DOMReader;
import org.dom4j.io.SAXReader;

public class Tools {

	public static void main(String[] args) {
		SAXReader saxReader = new SAXReader();

		Document document = null;
		try {
			document = saxReader.read(new File("D:\\EclipseWorkSpace\\xml\\src\\main\\java\\xml\\xml\\students.xml"));
		} catch (DocumentException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		// 获取根元素
		Element root = document.getRootElement();

		// 获取所有子元素
		List<Element> childList = root.elements();

		for (Element e : childList) {
			if ("Body".equals(e.getName())) {
				List<Element> data = e.elements();
				Element ee = data.get(0);
				List<Element> eee = ee.elements();
				for (Element el : eee) {
					if ("terminals".equals(el.getName())) {
						List<Element> eeee = el.elements();
						Element sd = eeee.get(0);
						List<Element> list = sd.elements();
						for (Element asd : list) {
							String ssss = asd.getName();

							System.out.println("if (\"" + ssss + "\".equalsIgnoreCase(n.getLocalName())) {\n"
									+ "System.out.println(\"" + ssss + "为：\" + n.getTextContent() + \";\");\n" + "}");

							if ("rating".equals(ssss)) {
								System.out.println("---------------------------------------------------------");
								List<Element> rs = asd.elements();
								for (Element rss : rs) {
									String sssss = rss.getName();
									System.out.println("if (\"" + sssss + "\".equalsIgnoreCase(ra.getLocalName())) {\n"
											+ "System.out.println(\"" + sssss + "为：\" + ra.getTextContent() + \";\");\n"
											+ "}");
								}
								System.out.println("---------------------------------------------------------");

							}

						}
					}
				}
			}
		}

	}

}
