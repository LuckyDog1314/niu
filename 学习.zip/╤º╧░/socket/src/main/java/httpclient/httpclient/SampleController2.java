package httpclient.httpclient;


import java.io.IOException;
import java.util.Enumeration;
import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.boot.*;
import org.springframework.boot.autoconfigure.*;
import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.*;

@Controller
@EnableAutoConfiguration
public class SampleController2 {

	@RequestMapping(value = "httpClientGet", method = RequestMethod.GET, produces = "text/html;charset=utf-8")
	@ResponseBody
	public String get(HttpServletRequest request, HttpServletResponse response) throws IOException {

		Enumeration<String>	parameterNames=request.getParameterNames();
		
		String parameters="";
	    while(parameterNames.hasMoreElements()){
	      String name=parameterNames.nextElement();
	      String value=request.getParameter(name);
	     parameters+=name+"="+value+"&";
	    }
	    parameters=parameters.substring(0, parameters.length()-1);
	    String json=new ParameterJsonConversion().parameterToJson(parameters);
	    System.out.println(json);
	    System.out.println("GET");
		return "get";

	}

	@RequestMapping(value = "httpClientPost", method = RequestMethod.POST, produces = "text/html;charset=utf-8")
	@ResponseBody
	public String post(HttpServletRequest request, HttpServletResponse response) throws IOException {

		// BufferedReader br = request.getReader();
		// String str, wholeStr = "";
		// while((str = br.readLine()) != null){
		// wholeStr += str;
		// }
		// System.out.println(wholeStr);

		int len = request.getContentLength();
		ServletInputStream iii = request.getInputStream();
		byte[] buffer = new byte[len];

		String json = "";
		while (iii.read(buffer, 0, len) != -1) {
			json += new String(buffer);
		}
		System.out.println(json);
        System.out.println("POST");
		return "post";

	}

	public static void main(String[] args) throws Exception {
		SpringApplication.run(SampleController2.class, args);
	}
}
