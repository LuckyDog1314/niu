package httpclient.httpclient;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.HttpEntity;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.springframework.boot.*;
import org.springframework.boot.autoconfigure.*;
import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.*;




@Controller
@EnableAutoConfiguration
public class YZFSampleController {

	@RequestMapping(value = "yzf", method = RequestMethod.GET, produces = "text/html;charset=utf-8")
	@ResponseBody
	public String get(HttpServletRequest request, HttpServletResponse res) throws IOException {

		   //获取访问令牌
	       // 创建默认的httpClient实例.
			CloseableHttpClient httpclient = HttpClients.createDefault();
			// 创建httppost
			String url="http://beta.open.limofang.cn/"+request.getParameter("url");
			String person=request.getParameter("person");
			
			long currentTimeMillis=System.currentTimeMillis();
			String common=null;
			try {
				common = "wid=1022&token="+MD5Utils.getMd5_32("1022TgjRqV4neWPY3HU6XCK8RASaDBytEm"+currentTimeMillis).toUpperCase()+"&timestamp="+currentTimeMillis;
			} catch (NoSuchAlgorithmException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}
			
			if(person!=null){
				person=person.replaceAll("-", "&");
				person="&"+person;
				url=url+"?"+common+person;
			}else{
				url=url+"?"+common;
			}
			HttpPost httppost = new HttpPost(url);

			HttpEntity jsonEntity = null;
			String result=null;
		
			jsonEntity = new StringEntity("", ContentType.APPLICATION_JSON);
	        
			try {
				httppost.setEntity(jsonEntity);
				CloseableHttpResponse response1 = httpclient.execute(httppost);
				try {
					HttpEntity entity1 = response1.getEntity();
					if (entity1 != null) {
					result=EntityUtils.toString(entity1, "UTF-8");
					System.out.println(url);
					System.out.println(result);
				    }
				} finally {
					response1.close();
				}
			} catch (ClientProtocolException e) {
				e.printStackTrace();
			} catch (UnsupportedEncodingException e1) {
				e1.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				// 关闭连接,释放资源
				try {
					httpclient.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}       

		return result;

	}

	
	public static void main(String[] args) throws Exception {
		SpringApplication.run(YZFSampleController.class, args);
	}
}
