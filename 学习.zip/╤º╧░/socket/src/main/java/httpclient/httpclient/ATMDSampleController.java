package httpclient.httpclient;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.HttpEntity;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;
import org.apache.http.util.EntityUtils;
import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.boot.*;
import org.springframework.boot.autoconfigure.*;
import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.*;




@Controller
@EnableAutoConfiguration
public class ATMDSampleController {

	@RequestMapping(value = "atmd", method = RequestMethod.GET, produces = "text/html;charset=utf-8")
	@ResponseBody
	public String get(HttpServletRequest request, HttpServletResponse res) throws IOException {

		//获取访问令牌
		// 创建默认的httpClient实例.
				CloseableHttpClient httpclient1 = HttpClients.createDefault();
				// 创建httppost
				HttpPost httppost1 = new HttpPost("http://api.st.97ting.com:8001/ContentServiceWS/OAuth/getAccessTokenSig?oauth_consumer_key=CXAndroidClient&oauth_consumer_sig=D59A499C71B4B1D62602ECF325EDA8E0&clientid=AndroidClient&clientsecret=1");

				HttpEntity jsonEntity1 = null;
			
				jsonEntity1 = new StringEntity("", ContentType.APPLICATION_JSON);
		        
				String access_token=null;
				String token_secret=null;
				String refresh_token=null;
				
				try {
					httppost1.setEntity(jsonEntity1);
					CloseableHttpResponse response1 = httpclient1.execute(httppost1);
					try {
						HttpEntity entity1 = response1.getEntity();
						if (entity1 != null) {
						String json=EntityUtils.toString(entity1, "UTF-8");
						ObjectMapper mapper = new ObjectMapper();
						JsonNode jsonNode=mapper.readTree(json);
						access_token=jsonNode.get("response").get("docs").get("access_token").asText();
						token_secret=jsonNode.get("response").get("docs").get("token_secret").asText();
						refresh_token=jsonNode.get("response").get("docs").get("refresh_token").asText();
						}
					} finally {
						response1.close();
					}
				} catch (ClientProtocolException e) {
					e.printStackTrace();
				} catch (UnsupportedEncodingException e1) {
					e1.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				} finally {
					// 关闭连接,释放资源
					try {
						httpclient1.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}

//				System.out.println("访问令牌>>>>>>>>>>>>>>");
//				System.out.println(MD5Utils.getMd5_32("CXAndroidClient"+"AndroidClient"+"1"+"0e330d0a46793460309d58ae6f38f48a").toUpperCase());
//				System.out.println("更新令牌>>>>>>>>>>>>>>");
//				System.out.println(MD5Utils.getMd5_32("CXAndroidClient"+"54e6aed14551bcf41ba625322ee474e8"+"3335238fa5d39fab18675a919b0e7005"+"0e330d0a46793460309d58ae6f38f48a").toUpperCase());
				String update=request.getParameter("update");
				if("update".equals(update)){
					String md5=null;
					try {
						md5=MD5Utils.getMd5_32("CXAndroidClient"+refresh_token+token_secret+"0e330d0a46793460309d58ae6f38f48a").toUpperCase();
					} catch (NoSuchAlgorithmException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					
					CloseableHttpClient httpclient2 = HttpClients.createDefault();
					// 创建httppost
					HttpPost httppost2 = new HttpPost("http://api.st.97ting.com:8001/ContentServiceWS/OAuth/refreshAccessTokenSig?oauth_consumer_key=CXAndroidClient&oauth_consumer_sig="+md5+"&refresh_token="+refresh_token+"&token_secret="+token_secret);

					HttpEntity jsonEntity2 = null;
				
					jsonEntity2 = new StringEntity("", ContentType.APPLICATION_JSON);
			        
					
					try {
						httppost1.setEntity(jsonEntity2);
						CloseableHttpResponse response2 = httpclient2.execute(httppost2);
						try {
							HttpEntity entity2 = response2.getEntity();
							if (entity2 != null) {
							return EntityUtils.toString(entity2, "UTF-8");
					}
						} finally {
							response2.close();
						}
					} catch (ClientProtocolException e) {
						e.printStackTrace();
					} catch (UnsupportedEncodingException e1) {
						e1.printStackTrace();
					} catch (IOException e) {
						e.printStackTrace();
					} finally {
						// 关闭连接,释放资源
						try {
							httpclient1.close();
						} catch (IOException e) {
							e.printStackTrace();
						}
					}	
					
					
				}
				
				
				
				
				
		
		String url = request.getParameter("url");
		url=url.replaceAll("~", "&");
		System.out.println(url);
		// 创建默认的httpClient实例.
		CloseableHttpClient httpclient = HttpClients.createDefault();
		// 创建httppost
		HttpPost httppost = new HttpPost(url);

		httppost.addHeader("oauth_token", access_token);

		String result = null;
		HttpEntity jsonEntity = null;
		HttpContext localContext = new BasicHttpContext();
		
		localContext.setAttribute("OAuth_UserID", "1");
		jsonEntity = new StringEntity("", ContentType.APPLICATION_JSON);
        
		try {

			httppost.setEntity(jsonEntity);
			System.out.println("executing request " + httppost.getURI());
			CloseableHttpResponse response = httpclient.execute(httppost,localContext);
			try {
				HttpEntity entity = response.getEntity();
				if (entity != null) {
					result = EntityUtils.toString(entity, "UTF-8");
					System.out.println(result);
				}
			} finally {
				response.close();
			}
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e1) {
			e1.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			// 关闭连接,释放资源
			try {
				httpclient.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		return result;

	}

	@RequestMapping(value = "a", method = RequestMethod.GET, produces = "text/html;charset=utf-8")
	@ResponseBody
	public String get1(HttpServletRequest request, HttpServletResponse response) throws IOException {
		System.out.println(1);
		return "1";
	}

	@RequestMapping(value = "b", method = RequestMethod.GET, produces = "text/html;charset=utf-8")
	@ResponseBody
	public String get2(HttpServletRequest request, HttpServletResponse response) throws IOException {
		System.out.println(2);
		return "2";
	}
	
	@RequestMapping(value = "c", method = RequestMethod.GET, produces = "text/html;charset=utf-8")
	@ResponseBody
	public String get3(HttpServletRequest request, HttpServletResponse response) throws IOException {
		System.out.println(3);
		return "3";
	}
	
	public static void main(String[] args) throws Exception {
		SpringApplication.run(ATMDSampleController.class, args);
	}
}
