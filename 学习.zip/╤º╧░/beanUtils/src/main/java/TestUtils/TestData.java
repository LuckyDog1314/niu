package TestUtils;

public class TestData {
	/**
	 * 编号
	 */
	private String number;
	/**
	 * 概要
	 */
	private String outLine;
	/**
	 * 详细描述
	 */
//	private String elaborate;
	/**
	 * 分类
	 */
	private String classify;
	/**
	 * 请求头部信息
	 */
	private String requestHead;
	/**
	 * 请求消息体
	 */
	private String requestBody;
	/**
	 * db条件
	 */
	private String condition;
	/**
	 * DB数据
	 */
	private String dbData;
	/**
	 * 返回头部消息
	 */
	private String ResponseHead;
	/**
	 * 返回消息体
	 */
	private String ResponseBody;

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getOutLine() {
		return outLine;
	}

	public void setOutLine(String outLine) {
		this.outLine = outLine;
	}

//	public String getElaborate() {
//		return elaborate;
//	}
//
//	public void setElaborate(String elaborate) {
//		this.elaborate = elaborate;
//	}

	public String getClassify() {
		return classify;
	}

	public void setClassify(String classify) {
		this.classify = classify;
	}

	public String getDbData() {
		return dbData;
	}

	public void setDbData(String dbData) {
		this.dbData = dbData;
	}

	public String getRequestHead() {
		return requestHead;
	}

	public void setRequestHead(String requestHead) {
		this.requestHead = requestHead;
	}

	public String getRequestBody() {
		return requestBody;
	}

	public void setRequestBody(String requestBody) {
		this.requestBody = requestBody;
	}

	public String getCondition() {
		return condition;
	}

	public void setCondition(String condition) {
		this.condition = condition;
	}

	public String getResponseHead() {
		return ResponseHead;
	}

	public void setResponseHead(String responseHead) {
		ResponseHead = responseHead;
	}

	public String getResponseBody() {
		return ResponseBody;
	}

	public void setResponseBody(String responseBody) {
		ResponseBody = responseBody;
	}
}
