package TestUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;
import beanUtils.beanUtils.ExcelUtils;
import beanUtils.beanUtils.ExcelUtils.CallBackExcelSingleRow;
import beanUtils.beanUtils.StringUtils;

public class TestTest {

	static ArrayList<TestData> arrayList = new ArrayList<TestData>();

	static String mdb = "AM";
	static String number = "0021";
	static String name = "车辆阈值查询";
	static int checkBegin = 0;
	static int checkEnd = 0;
	static String defaultCollection = "ThresholdSettingContent";

	static String defaultName = defaultCollection.substring(0, 1).toLowerCase() + defaultCollection.substring(1);
	static String packageName = mdb.toLowerCase();
	static String component = "FN" + number;
	static String fid = mdb + component;
	static String fn = "fn" + number;

	public static void main(String[] args) {
		String path = "D:\\platform-document\\40_测试\\10_UT\\011_账户管理\\功能测试用例（011_" + number + "）_" + name + ".xlsx";
		try {
			TestTest.readDate(path, 0, 30);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// 导入代码模板----------------------------------------------------
		String code = "package cn.sh.changxing.bs." + packageName
				+ ";import org.codehaus.jackson.type.TypeReference;import org.junit.Assert;import org.junit.Before;import org.junit.Test;import org.junit.runner.RunWith;import org.springframework.beans.factory.annotation.Autowired;import org.springframework.beans.factory.annotation.Value;import org.springframework.boot.autoconfigure.SpringBootApplication;import org.springframework.context.annotation.PropertySource;import org.springframework.data.mongodb.core.query.Query;import org.springframework.test.context.junit4.SpringRunner;import cn.sh.changxing.common.utils.JsonUtils;import cn.sh.changxing.platform.test.UnitTest;\n";

		code += "/**\n* " + name
				+ "\n* @author niushunyuan\n*\n*/@RunWith(SpringRunner.class)\n@SpringBootApplication\n@PropertySource(value = { \"application_am_test.properties\", \"request_data_am.properties\", \"db_data_am.properties\" })\npublic class "
				+ component + "Test extends UnitTest {\n// 测试功能服务\n@Autowired\nprivate " + fid + " " + fn
				+ ";\n@Autowired\nprivate MDBTemplate" + mdb + " mdbTemplate" + mdb + ";\n";
		// 导入请求体---------------------------------------------------------
		String reqData = "";
		String reqProperties = "#" + component + "\n";
		for (TestData data : arrayList) {
			String number = data.getNumber();
			if (number.matches("[1-9]")) {
				number = "0" + number;
			}
			if (StringUtils.isNotEmpty(data.getRequestHead())) {
				reqData += "@Value(\"${" + component + "_reqHead" + number + "}\")\nprivate String reqHead" + number
						+ ";\n";
				reqProperties += component + "_reqHead" + number + "=" + data.getRequestHead().replaceAll("\n", "")
						.replaceAll(" ", "").replaceAll("\t", "").replaceAll("\r", "") + "\n";
			}
			if (StringUtils.isNotEmpty(data.getRequestBody())) {
				reqData += "@Value(\"${" + component + "_reqBody" + number + "}\")\nprivate String reqBody" + number
						+ ";\n";
				reqProperties += component + "_reqBody" + number + "=" + data.getRequestBody().replaceAll("\n", "")
						.replaceAll(" ", "").replaceAll("\t", "").replaceAll("\r", "") + "\n";
			}
		}
		code += reqData;
		System.out.println(reqProperties);
		// 导入MongoDB数据----------------------------------------------------------------------------
		String monData = "";
		String monProperties = "#" + component + "\n";
		for (TestData data : arrayList) {
			String number = data.getNumber();
			if (number.matches("[1-9]")) {
				number = "0" + number;
			}
			if (StringUtils.isNotEmpty(data.getDbData())) {
				String dbData = data.getDbData();
				String[] dbs = dbData.split("&&");
				if (dbs.length == 1) {
					monData += "@Value(\"${" + component + "_MongoData" + number + "}\")\nprivate String " + component
							+ "_MongoData" + number + ";\n";
					monProperties += component + "_MongoData" + number + "=" + data.getDbData().replaceAll("\n", "")
							.replaceAll(" ", "").replaceAll("\t", "").replaceAll("\r", "") + "\n";
				} else {
					for (int i = 0; i < dbs.length; i++) {
						String db = dbs[i];
						String nu = "" + (i + 1);
						if (i + 1 < 10) {
							nu = "0" + nu;
						}

						monData += "@Value(\"${" + component + "_MongoData" + number + "_" + nu
								+ "}\")\nprivate String " + component + "_MongoData" + number + "_" + nu + ";\n";
						monProperties += component + "_MongoData" + number + "_" + nu + "="
								+ db.replaceAll("\n", "").replaceAll(" ", "").replaceAll("\t", "").replaceAll("\r", "")
								+ "\n";
					}
				}
			}
		}
		code += monData;
		System.out.println(monProperties);
		// 导入测试用例----------------------------------------------------------------------
		for (TestData data : arrayList) {
			String number = data.getNumber();
			int flag = Integer.parseInt(number);
			if (number.matches("[1-9]")) {
				number = "0" + number;
			}
			if (flag >= checkBegin && flag <= checkEnd) {
				code += "/**参数检查\n*";
			} else {
				code += "/**业务处理\n*";
			}
			code += data.getClassify() + "\n *" + data.getOutLine() + "*/\n@Test\npublic void test_" + number
					+ "() throws Exception {\n// 删除数据\nmdbTemplate" + mdb + ".remove(new Query(), " + defaultCollection
					+ ".class);\n";
			if (StringUtils.isNotEmpty(data.getDbData())) {
				String dbData = data.getDbData();
				String[] dbs = dbData.split("&&");
				if (dbs.length == 1) {
					code += "//添加数据\n" + defaultCollection + " " + defaultName + " = JsonUtils.fromJson(" + component
							+ "_MongoData" + number + ", new TypeReference<" + defaultCollection
							+ ">() {});\nmdbTemplate" + mdb + ".insert(" + defaultName + ");\n";
				} else {
					for (int i = 0; i < dbs.length; i++) {

						String nu = "" + (i + 1);
						if (i + 1 < 10) {
							nu = "0" + nu;
						}
						if (i == 0) {
							code += "//添加数据\n" + defaultCollection + " " + defaultName + " = JsonUtils.fromJson("
									+ component + "_MongoData" + number + "_" + nu + ", new TypeReference<"
									+ defaultCollection + ">() {});\nmdbTemplate" + mdb + ".insert(" + defaultName
									+ ");\n";
						} else {
							code += "//添加数据\n" + "AA" + " " + "BB" + " = JsonUtils.fromJson(" + component + "_MongoData"
									+ number + "_" + nu + ", new TypeReference<" + "AA" + ">() {});\nmdbTemplate" + mdb
									+ ".insert(" + "BB" + ");\n";
						}

					}
				}

			}
			code += "// 请求数据\n" + fid + "RequestBody req = JsonUtils.fromJson(reqBody" + number + ", new TypeReference<"
					+ fid + "RequestBody>() {});\n";
			if (StringUtils.isNotEmpty(data.getRequestHead())) {
				code += "EntityHead head = JsonUtils.fromJson(reqHead" + number
						+ ", new TypeReference<EntityHead>() {});\n" + fid + "ResponseBody res = " + fn
						+ ".onRequest(head,req);\n";
			} else {
				code += fid + "ResponseBody res = " + fn + ".onRequestBody(req);\n";
			}

			code += "System.out.println(JsonUtils.toJson(res));\nAssert.assertNotNull(res);\n";
			if (flag >= checkBegin && flag <= checkEnd) {
				code += "Assert.assertEquals(" + fid + ".BUSINESS_FUNCTION_ID + \".\" + " + fid
						+ ".,res.getCommon().getError().get(" + (flag - 1) + ").getErrorCode());";
			}
			code += "}";
		}

		code += "}";
		try {
			File file = new File("D:\\JavaBean", component + "Test.java");
			@SuppressWarnings("resource")
			PrintStream ps = new PrintStream(new FileOutputStream(file));
			ps.println(code);// 往文件里写入字符串
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
	}

	public static void readDate(String path, final int beginLine, final int endLine) throws Exception {

		InputStream input = new FileInputStream(new File(path));
		ExcelUtils.readExcel(input, ExcelUtils.EXCEL_FORMAT_XLSX, 1, new CallBackExcelSingleRow() {

			public void readRow(List<String> rowContent, int rowIndex) {
				if (rowIndex >= beginLine && rowIndex <= endLine) {
					String number = rowContent.get(0).trim();
					if (number.matches("^[0-9]*[1-9][0-9]*$")) {
						TestData testData = new TestData();
						testData.setNumber(number);
						String outLine = rowContent.get((1)).trim();
						testData.setOutLine(outLine);
						// String elaborate = rowContent.get((2)).trim();
						// testData.setElaborate(elaborate);
						String classify = rowContent.get((3)).trim();
						testData.setClassify(classify);
						String requestHead = rowContent.get((4)).trim();
						testData.setRequestHead(requestHead);
						String requestBody = rowContent.get((5)).trim();
						testData.setRequestBody(requestBody);
						String condition = rowContent.get((6)).trim();
						testData.setCondition(condition);
						String dbData = rowContent.get((7)).trim();
						testData.setDbData(dbData);
						String responseHead = rowContent.get((8)).trim();
						testData.setResponseHead(responseHead);
						String responseBody = rowContent.get((9)).trim();
						testData.setResponseBody(responseBody);
						arrayList.add(testData);
					}
				}
			}
		});
	}
}
