package beanUtils.beanUtils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;

public class BeanUtils {

	String nttFilePath = "D:/JavaBean/ntt";
	String fnFilePath = "D:/JavaBean/fn";

	public static void main(String[] args) {
		BeanUtils bu = new BeanUtils();
		int i = 1;
		String mdb = "OM";
		String packageName = "om";
		String fid = mdb + "FN000" + i;

		String component = "FN000" + i;
		if (i > 9) {
			fid = mdb + "FN00" + i;
			component = "FN00" + i;
		}
		
		bu.fn(packageName, fid, component, mdb);
		bu.req(packageName, fid);
		bu.reqData(packageName, fid);
		bu.res(packageName, fid);
		bu.resData(packageName, fid);
	

	}

	public void fn(String packageName, String fid, String component, String mdb) {
		String result = "package cn.sh.changxing.bs." + packageName
				+ ";import org.slf4j.Logger;import org.slf4j.LoggerFactory;import org.springframework.beans.factory.annotation.Autowired;import org.springframework.stereotype.Component;import cn.sh.changxing.entity."
				+ packageName + "." + fid + "RequestBody;import cn.sh.changxing.entity." + packageName + "." + fid
				+ "ResponseBody;import cn.sh.changxing.mdb." + packageName + ".MDBTemplate" + mdb
				+ ";import cn.sh.changxing.platform.service.provide.EntityFunctionProvide;import cn.sh.changxing.platform.service.provide.ProvideException;@Component(\""
				+ component + "\")public class " + fid + " extends EntityFunctionProvide<" + fid + "RequestBody, " + fid
				+ "ResponseBody>{private static final Logger LOG=LoggerFactory.getLogger(" + fid
				+ ".class);@Autowired private MDBTemplate" + mdb + " mdbTemplate" + mdb + ";@Override protected " + fid
				+ "ResponseBody onRequestBody(" + fid + "RequestBody req) throws ProvideException {LOG.info(\"\");"
				+ fid + "ResponseBody res=new " + fid
				+ "ResponseBody();res.setSerialNumber(req.getCommon().getSerialNumber());return res;}}";

		try {
			File file = new File(fnFilePath, fid + ".java");
			PrintStream ps = new PrintStream(new FileOutputStream(file));
			ps.println(result);// 往文件里写入字符串
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void req(String packageName, String fid) {
		String result = "package cn.sh.changxing.entity." + packageName
				+ ";import org.codehaus.jackson.annotate.JsonProperty;import cn.sh.changxing.platform.EntityRequestBody;public class "
				+ fid + "RequestBody extends EntityRequestBody {@JsonProperty(\"da\")private " + fid
				+ "RequestBodyData data=new " + fid + "RequestBodyData();public void setData(" + fid
				+ "RequestBodyData data) {this.data = data;}public " + fid
				+ "RequestBodyData getData() {return data;}}";

		try {
			File file = new File(nttFilePath, fid + "RequestBody.java");
			PrintStream ps = new PrintStream(new FileOutputStream(file));
			ps.println(result);// 往文件里写入字符串
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void reqData(String packageName, String fid) {
		String result = "package cn.sh.changxing.entity." + packageName
				+ ";import org.codehaus.jackson.annotate.JsonProperty;public class " + fid + "RequestBodyData{";
		result += "}";

		try {
			File file = new File(nttFilePath, fid + "RequestBodyData.java");
			PrintStream ps = new PrintStream(new FileOutputStream(file));
			ps.println(result);// 往文件里写入字符串
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void res(String packageName, String fid) {
		String result = "package cn.sh.changxing.entity." + packageName
				+ ";import org.codehaus.jackson.annotate.JsonProperty;import cn.sh.changxing.platform.EntityResponseBody;public class "
				+ fid + "ResponseBody extends EntityResponseBody {@JsonProperty(\"da\")private " + fid
				+ "ResponseBodyData data;public void setData(" + fid
				+ "ResponseBodyData data) {this.data = data;}public " + fid
				+ "ResponseBodyData getData() {return data;}}";

		try {
			File file = new File(nttFilePath, fid + "ResponseBody.java");
			PrintStream ps = new PrintStream(new FileOutputStream(file));
			ps.println(result);// 往文件里写入字符串
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void resData(String packageName, String fid) {
		String result = "package cn.sh.changxing.entity." + packageName
				+ ";import org.codehaus.jackson.annotate.JsonProperty;public class " + fid + "ResponseBodyData {";
		result += "}";

		try {
			File file = new File(nttFilePath, fid + "ResponseBodyData.java");
			PrintStream ps = new PrintStream(new FileOutputStream(file));
			ps.println(result);// 往文件里写入字符串
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
