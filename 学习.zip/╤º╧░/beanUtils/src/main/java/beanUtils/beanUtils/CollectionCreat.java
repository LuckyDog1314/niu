package beanUtils.beanUtils;


import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import beanUtils.beanUtils.ExcelUtils;
import beanUtils.beanUtils.ExcelUtils.CallBackExcelSingleRow;

public class CollectionCreat {
	
	public static void main(String[] args) throws Exception {
		showBean("D:\\MongoDB.xlsx", 0, 13, 1);
	}
	
	public static void showBean(String path,final int beginLine,final int endLine, final int beginRow) throws Exception{
		InputStream input = new FileInputStream(new File(path));
		ExcelUtils.readExcel(input, ExcelUtils.EXCEL_FORMAT_XLSX, 1, new CallBackExcelSingleRow() {
			
			ArrayList<CreateCondition> conditions = new ArrayList<CreateCondition>();
			
			public void readRow(List<String> rowContent, int rowIndex) {
				if(rowIndex >= beginLine && rowIndex <= endLine){
					String shortName = rowContent.get(0).trim();//缩写
					String name = rowContent.get(1).trim();//全称
					String desc = rowContent.get(2).trim();//描述
					conditions.add(getCondition(name, shortName, desc));
				}
				if(rowIndex == endLine){
					conditions.trimToSize();
					for(CreateCondition condition:conditions){
						ShortDesc(condition);	
					}
					for(CreateCondition condition:conditions){
						Area(condition);
					}
				}
			}
		});	
	}
	
	private static CreateCondition getCondition(String name,String shortName, String desc){
		return new CreateCondition(name, shortName, desc);
	}
	
	private static void ShortDesc(CreateCondition condition){
		if("_id".equals(condition.getShortName())){
			System.out.println("public static final String COLLECTION_NAME=\""+condition.getBigName()+"\";");
		}else{
			System.out.println("public static final String " + condition.getBigName() + " = \"" + condition.getShortName() + "\";");
		}
	}
	
	private static void Area(CreateCondition condition){
		System.out.println("/**");
		System.out.println("*  " + condition.getDesc());
		System.out.println("*/");
		if("objectId".equals(condition.getDesc())){
			System.out.println("@Id");
			System.out.println("private ObjectId _id;");
		}else{
			System.out.println("@Field(" + condition.getBigName() + ")");
			System.out.println("private String " + condition.getName() + ";");
		}
	}
}

class CreateCondition{
	private String name = "";
	private String shortName = "";
	private String desc = "";
	
	public CreateCondition(String name, String shortName, String desc) {
		this.name = name;
		this.shortName = shortName;
		this.desc = desc;
	}

	public String getName() {
		String bigName = name;
		String[] str=bigName.split("_");
		StringBuilder sBuild = new StringBuilder();
		
		for(int i=0;i<str.length;i++){
			 String ss=str[i];
			 if(i==0){
				 ss=ss.toLowerCase();
			 }else{
				 ss = ss.substring(0, 1)+ss.substring(1).toLowerCase();
			 }
			sBuild.append(ss);
		}
		
		return sBuild.toString();
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getShortName() {
		return shortName;
	}

	public void setShortName(String shortName) {
		this.shortName = shortName;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}
	
	public String getBigName(){
		String bigName = name;
	
		return bigName;
	}
}
