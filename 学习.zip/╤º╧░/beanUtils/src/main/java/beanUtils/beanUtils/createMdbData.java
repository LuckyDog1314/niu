package beanUtils.beanUtils;


import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import beanUtils.beanUtils.ExcelUtils;
import beanUtils.beanUtils.ExcelUtils.CallBackExcelSingleRow;

public class createMdbData {
	
	public static void main(String[] args) throws Exception {
		showBean("D:\\12.xlsx", 0, 40, 1);
	}
	
	public static void showBean(String path,final int beginLine,final int endLine, final int beginRow) throws Exception{
		InputStream input = new FileInputStream(new File(path));
		ExcelUtils.readExcel(input, ExcelUtils.EXCEL_FORMAT_XLSX, 1, new CallBackExcelSingleRow() {
			
			ArrayList<CreateCondition1> conditions = new ArrayList<CreateCondition1>();
			
			public void readRow(List<String> rowContent, int rowIndex) {
				if(rowIndex >= beginLine && rowIndex <= endLine){
					String shortName = rowContent.get(0).trim();//缩写
					conditions.add(getCondition(shortName));
				}
				if(rowIndex == (endLine + 1)){
					conditions.trimToSize();
					for(CreateCondition1 condition:conditions){
						ShortDesc(condition);
					}
				}
			}
		});	
	}
	
	private static CreateCondition1 getCondition(String shortName){
		return new CreateCondition1(shortName);
	}
	
	private static void ShortDesc(CreateCondition1 condition){
		System.out.println("\""+condition.getShortName()+"\":\"1\",");
	}
	
}

class CreateCondition1{
	private String shortName = "";
	public CreateCondition1(String shortName) {
		this.shortName = shortName;
	}
	public String getShortName() {
		return shortName;
	}

	public void setShortName(String shortName) {
		this.shortName = shortName;
	}

}
