package beanUtils.beanUtils;


import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import beanUtils.beanUtils.ExcelUtils;
import beanUtils.beanUtils.ExcelUtils.CallBackExcelSingleRow;

public class mdbResultToResData {
	
	public static void main(String[] args) throws Exception {
		showBean("D:\\12.xlsx", 21, 33, 1);
	}
	
	public static void showBean(String path,final int beginLine,final int endLine, final int beginRow) throws Exception{
		InputStream input = new FileInputStream(new File(path));
		ExcelUtils.readExcel(input, ExcelUtils.EXCEL_FORMAT_XLSX, 1, new CallBackExcelSingleRow() {
			
			ArrayList<ddCreateCondition> conditions = new ArrayList<ddCreateCondition>();
			
			public void readRow(List<String> rowContent, int rowIndex) {
				if(rowIndex >= beginLine && rowIndex <= endLine){
					String name = rowContent.get(0).trim();//全称
					conditions.add(getCondition(name));
				}
				if(rowIndex == (endLine + 1)){
					conditions.trimToSize();
					for(ddCreateCondition condition:conditions){
						Area(condition);
					}
				}
			}
		});	
	}
	
	private static ddCreateCondition getCondition(String name){
		return new ddCreateCondition(name);
	}
	
	private static void Area(ddCreateCondition condition){
		System.out.println("resData.set" + condition.getName() +"(vehicleStandard.get"+condition.getName()+"())"+ ";");
	}
}

class ddCreateCondition{
	private String name = "";
	
	public ddCreateCondition(String name) {
		this.name = name;
	}

	public String getName() {
		String bigName = name;
		
		bigName=bigName.substring(0, 1).toUpperCase()+bigName.substring(1);
		
		return bigName;
	}

	public void setName(String name) {
		this.name = name;
	}
}
