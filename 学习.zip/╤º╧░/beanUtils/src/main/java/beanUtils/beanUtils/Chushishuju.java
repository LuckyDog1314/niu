package beanUtils.beanUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import beanUtils.beanUtils.ExcelUtils.CallBackExcelSingleRow;

public class Chushishuju {

	public static void main(String[] args) throws Exception {
		showBean("D:\\12.xlsx", 0, 23, 1);
	}
	
	public static void showBean(String path,final int beginLine,final int endLine, final int beginRow) throws Exception{
		InputStream input = new FileInputStream(new File(path));
		ExcelUtils.readExcel(input, ExcelUtils.EXCEL_FORMAT_XLSX, 1, new CallBackExcelSingleRow() {
			
			public void readRow(List<String> rowContent, int rowIndex) {
				if(rowIndex >= beginLine && rowIndex <= endLine){
					String a = rowContent.get(0).trim();
					String b = rowContent.get(1).trim();
					String c = rowContent.get(2).trim();
					String d = rowContent.get(3).trim();
					String e = rowContent.get(4).trim();
					System.out.println("{\"bid\":\""+a+"\",\"fid\":\""+b+"\",\"dety\":\""+c+"\",\"accef\":\""+d+"\",\"decef\":\""+e+"\"},");
				}
				
			}
		});	
	}
	
}
