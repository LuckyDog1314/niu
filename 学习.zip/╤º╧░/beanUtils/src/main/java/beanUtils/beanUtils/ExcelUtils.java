package beanUtils.beanUtils;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.formula.eval.ErrorEval;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 * 解析excel表格
 * 
 * @author meizhikang
 *
 */
public class ExcelUtils {
	
	public static final int READ_ALL_SHEET = -1;
	
	public static final int EXCEL_FORMAT_XLS = 0;
	public static final int EXCEL_FORMAT_XLSX = 1;
	public static final int EXCEL_FORMAT_CSV = 2;
	
	public static final int ERROR_EXCEL_FORMAT = -1;
	
	private static final String EMPTY = "";
	private static final String DEFAULT_CHARSET = "utf-8";
	private static final String POINT_CODE = ",";
	
	/**
	 * 该方法是用来解析Excel表格的,每读取一行便调用CallBackExcelSingleRow回调函数，返回当前行所有列的数据和当前行在excel中属于第几行<br/>
	 * 对于csv格式的文件,返回的数据不会经过任何改变<br/>
	 * 1.对于excel中的公式,该接口当前返回的该公式的文档,不会进行相应的计算<br/>
	 * 2.对于boolean类型的数据,返回"TRUE"或者"FALSE"<br/>
	 * 3.对于时间类型的数据,接口当前返回的是yyyyMMdd格式的时间数据<br/>
	 * 
	 * @param excelInputStream 所要解析文件的输入流
	 * @param excelFormat 所要解析文件的格式,目前只能解析xls,xlsx和csv格式的文件
	 * @param readWhatSheet 如果解析的是xls和xlsx格式的文件,该参数表示读取文件中的哪一个Sheet表格,默认读取所有Sheet的数据
	 * @param singleRow readRow(currentRowContent, rowIndex) currentRowContent返回当前行的所有内容,rowIndex是当前所在Sheet的行数
	 */
	public static void readExcel(InputStream excelInputStream,int excelFormat,int readWhatSheet,CallBackExcelSingleRow singleRow) throws Exception{
		int needReadSheet = READ_ALL_SHEET;
		if(readWhatSheet >= 0){
			needReadSheet = readWhatSheet;
		}
		
		if(excelFormat == EXCEL_FORMAT_XLS){
			readXls(excelInputStream,singleRow,needReadSheet);
			return;
		}
		if(excelFormat == EXCEL_FORMAT_XLSX){
			readXlsx(excelInputStream,singleRow,needReadSheet);
			return;
		}
		if(excelFormat == EXCEL_FORMAT_CSV){
			readCsv(excelInputStream,singleRow);
			return;
		}
		
		singleRow.readRow(null, ERROR_EXCEL_FORMAT);
	}

	private static void readXls(InputStream excelInputStream,CallBackExcelSingleRow singleRow,int readWhatSheet) throws Exception{ 
		HSSFWorkbook excelDoc = new HSSFWorkbook(excelInputStream);
		int beginSheet = 0;
		int endSheet = excelDoc.getNumberOfSheets();
		if(readWhatSheet != READ_ALL_SHEET){
			beginSheet = readWhatSheet - 1;
			endSheet = readWhatSheet;
		}
				
		for(int currentSheet = beginSheet; currentSheet < endSheet; currentSheet++){
			HSSFSheet currentSheetDoc = excelDoc.getSheetAt(currentSheet);
			if(currentSheetDoc == null){
				continue;
			}
			for(int rowIndex = 0; rowIndex <= currentSheetDoc.getLastRowNum(); rowIndex++){
				HSSFRow currentRowDoc = currentSheetDoc.getRow(rowIndex);
				
				int currentRowFirstCol = currentRowDoc.getFirstCellNum();
				int currentRowLastCol = currentRowDoc.getLastCellNum();
				
				List<String> currentRowContent = new ArrayList<String>();
				
				for(int currentCol = currentRowFirstCol; currentCol < currentRowLastCol; currentCol++ ){
					HSSFCell currentCellDoc = currentRowDoc.getCell(currentCol);
					if(currentCellDoc == null){
						currentRowContent.add(EMPTY);
						continue;
					}
					currentRowContent.add(getHSSFWordbookCellContent(currentCellDoc));
				}
				singleRow.readRow(currentRowContent, rowIndex);
			}
		}
	}
	
	private static void readXlsx(InputStream excelInputStream,CallBackExcelSingleRow singleRow,int readWhatSheet) throws Exception{
		XSSFWorkbook excelDoc = new XSSFWorkbook(excelInputStream);
		int beginSheet = 0;
		int endSheet = excelDoc.getNumberOfSheets();
		if(readWhatSheet != READ_ALL_SHEET){
			beginSheet = readWhatSheet - 1;
			endSheet = readWhatSheet;
		}
		
		for(int currentSheet = beginSheet; currentSheet < endSheet; currentSheet++){
			XSSFSheet currentSheetDoc = excelDoc.getSheetAt(currentSheet);
			if(currentSheetDoc == null){
				continue;
			}
			for(int rowIndex = 0; rowIndex <= currentSheetDoc.getLastRowNum();rowIndex++){
				XSSFRow currentRowDoc = currentSheetDoc.getRow(rowIndex);
				if(currentRowDoc == null){
					continue;
				}
				
				int currentRowFirstCol = currentRowDoc.getFirstCellNum();
				int currentRowLastCol = currentRowDoc.getLastCellNum();
				List<String> currentRowContent = new ArrayList<String>();
				
				for(int currentCol = currentRowFirstCol; currentCol < currentRowLastCol; currentCol++){
					XSSFCell currentCellDoc = currentRowDoc.getCell(currentCol);
					if(currentCellDoc == null){
						currentRowContent.add(EMPTY);
						continue;
					}
					currentRowContent.add(getXSSFWordbookCellContent(currentCellDoc));
				}
				singleRow.readRow(currentRowContent, rowIndex);
			}
		}
	}
	
	private static void readCsv(InputStream excelInputStream,CallBackExcelSingleRow singleRow) throws Exception{
		BufferedReader csvReader = new BufferedReader(new InputStreamReader(excelInputStream,DEFAULT_CHARSET));
		String readLineContent;
		int rowIndex = 0;
		while((readLineContent = csvReader.readLine()) != null){
			String[] rowCodes = StringUtils.split(readLineContent, POINT_CODE);
			List<String> currentRowContent = new ArrayList<String>();
			for(String rowSingleCode:rowCodes){
				currentRowContent.add(rowSingleCode);
			}
			singleRow.readRow(currentRowContent, rowIndex);
			rowIndex ++;
		}
	}
	
	private static String getHSSFWordbookCellContent(HSSFCell xlsCell){
		switch (xlsCell.getCellType()) {
		case Cell.CELL_TYPE_BOOLEAN:
			return xlsCell.getBooleanCellValue()?"TRUE":"FALSE";
		case Cell.CELL_TYPE_ERROR:
			return ErrorEval.getText(xlsCell.getErrorCellValue());
		case Cell.CELL_TYPE_FORMULA:
			return xlsCell.getStringCellValue();
		case Cell.CELL_TYPE_NUMERIC:
			if(DateUtil.isCellDateFormatted(xlsCell)){
				return DateUtils.Date2String("yyyyMMdd", xlsCell.getDateCellValue());
			}
			xlsCell.setCellType(Cell.CELL_TYPE_STRING);
			return xlsCell.getStringCellValue();
		case Cell.CELL_TYPE_STRING:
			return xlsCell.getStringCellValue();
		default:
			return EMPTY;
		}
	}
	
	private static String getXSSFWordbookCellContent(XSSFCell xlsxCell){
		switch (xlsxCell.getCellType()) {
		case Cell.CELL_TYPE_BOOLEAN:
			return xlsxCell.getBooleanCellValue()?"TRUE":"FALSE";
		case Cell.CELL_TYPE_ERROR:
			return ErrorEval.getText(xlsxCell.getErrorCellValue());
		case Cell.CELL_TYPE_FORMULA:
			return xlsxCell.getStringCellValue();
		case Cell.CELL_TYPE_NUMERIC:
			if(DateUtil.isCellDateFormatted(xlsxCell)){
				return DateUtils.Date2String("yyyyMMdd", xlsxCell.getDateCellValue());
			}
			xlsxCell.setCellType(Cell.CELL_TYPE_STRING);
			return xlsxCell.getStringCellValue();
		case Cell.CELL_TYPE_STRING:
			return xlsxCell.getStringCellValue();
		default:
			return EMPTY;
		}
	}
	
	public interface CallBackExcelSingleRow{
		void readRow(List<String> rowContent,int rowIndex);
	}
}
