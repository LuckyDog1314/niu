package beanUtils.beanUtils;


public class FNCreateBean {

	
	public static void main(String[] args) {
		String str="OM";
		for(int i=1;i<14;i++){
			if(i<10){
				System.out.println("public static final API<"+str+"FN000"+i+"RequestBody, "+str+"FN000"+i+"ResponseBody> "+str+"_FN000"+i+" = new API<"+str+"FN000"+i+"RequestBody, "+str+"FN000"+i+"ResponseBody>("+str+", \"FN000"+i+"\", \"1.0\") {};");	
			}else{
				System.out.println("public static final API<"+str+"FN00"+i+"RequestBody, "+str+"FN00"+i+"ResponseBody> "+str+"_FN00"+i+" = new API<"+str+"FN00"+i+"RequestBody, "+str+"FN00"+i+"ResponseBody>("+str+", \"FN00"+i+"\", \"1.0\") {};");	
			}
		}
	}

}
