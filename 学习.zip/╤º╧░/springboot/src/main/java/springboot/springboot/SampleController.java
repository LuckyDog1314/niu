package springboot.springboot;

import java.io.File;
import java.io.IOException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.boot.*;
import org.springframework.boot.autoconfigure.*;
import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@Controller
@EnableAutoConfiguration
public class SampleController {

	@RequestMapping(value = "uploadFile", method = RequestMethod.POST, produces = "text/html;charset=utf-8")
	@ResponseBody
	public String uploadFile(@RequestParam("mof") MultipartFile file, HttpServletRequest request,
			HttpServletResponse response) throws IOException {

		response.addHeader("Access-Control-Allow-Origin", "*");
		// 临时文件存储路径为"D:\temporaryFiles\MD5"
		double size = 0;// 已传送文件大小
		String md5 = request.getParameter("md5");
		String fileName = request.getParameter("fileName");
		String uploadCompleted = request.getParameter("uploadCompleted");
		String fileSize = request.getParameter("fileSize");

		if(fileSize!=null){
			File root = new File("D:/temporaryFiles", md5);

			if (root.exists()) {
				File[] files = root.listFiles();
				for (File children : files) {
					if (children.isFile()) {
						size += children.length();
					}
				}
				
				if (size < Double.parseDouble(fileSize)) {
					File lastFile = new File("D:/temporaryFiles/" + md5, String.valueOf(files.length - 1));
					size -= lastFile.length();
					if (lastFile.exists()) {
						lastFile.delete();
					}
				}
	           
				return String.valueOf(size);
			} else {
				System.out.println("创建文件夹");
				root.mkdirs();
				
				File filePath = new File("D:/temporaryFiles/" + md5,"0");
				file.transferTo(filePath);
				
				return "success";
			}
		}
		
		
		for (int i = 0;; i++) {
			File filePath = new File("D:/temporaryFiles/" + md5, String.valueOf(i));
			if (!filePath.exists()) {
				file.transferTo(filePath);
				break;
			}
		}

		if ("uploadCompleted".equals(uploadCompleted)) {
			System.out.println(uploadCompleted);
			return "uploadCompleted";

		}

		return "success";

	}

	public static void main(String[] args) throws Exception {
		SpringApplication.run(SampleController.class, args);
	}
}
