$(document).ready(function() {
	upload({
		// 服务器地址
		'server' : 'http://localhost:8080/uploadFile',
		// 分片大小,默认为1M
		'blobSize' : 1024 * 1024,
		// 是否自动上传,默认为true
		'auto' : true,
		//上传完成后执行的事件
		'uploadCompleted' : function() {
			
		},
		//单个文件大小,默认为100M
		'fileSizeLimit':20*1024*1024,
		//文件类型,默认为所有文件(.*)
		'fileTypeExts':'.jpg,.png,.exe,.mp3,.mp4,.zip,.doc,.docx,.ppt,.pptx,.xls,.xlsx,.pdf'
	});
});
