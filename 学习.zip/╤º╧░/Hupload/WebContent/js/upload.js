//http://localhost:8080/uploadFile
var xhr = new XMLHttpRequest();
var fd;
var file;
var LENGTH = 1024 * 1024;
var start;
var end;
var blob;
var pecent;
var md5;
var P = 0;// 第几个
var fileList;
var notUploadFiles = [];// 未上传文件列表
var server;
var auto = true;
var uploadCompleted = function() {
};
var fileSizeLimit = 1000 * 1024 * 1024;
var fileTypeExts = ".*";
var fileTypeList = [];// 允许上传的文件类型列表

function upload(json) {
	server = json.server;
	if (typeof (json.blobSize) != "undefined") {
		LENGTH = json.blobSize;
	}
	if (typeof (json.auto) != "undefined") {
		auto = json.auto;
	}
	if (typeof (json.uploadCompleted) != "undefined") {
		uploadCompleted = json.uploadCompleted;
	}
	if (typeof (json.fileSizeLimit) != "undefined") {
		fileSizeLimit = json.fileSizeLimit;
	}
	if (typeof (json.fileTypeExts) != "undefined") {
		fileTypeExts = json.fileTypeExts;
		document.getElementById("file").accept=fileTypeExts.toLowerCase();
		fileTypeList = fileTypeExts.toLowerCase().split(",",
				fileTypeExts.length);
	}
}

// 文件队列
function fileQueue() {
	// var input=$('#file');
	// file = $('#file')[0].files[0];
	
	for(var m=0;m<notUploadFiles.length;m++){
		removeFileQueueId(m);
	}
	
	start = 0;
	end = LENGTH + start;
	fileList = document.getElementById("file");
	for (var i = 0; i < fileList.files.length; i++) {
		$('#list')
				.append(
						'<span>'
								+ fileList.files[i].name
								+ '</span><span id="show'
								+ i
								+ '"></span><br><div id="lala" style="float:left;width: 400px;background-color: red;height: 10px;"><div id="progress'
								+ i
								+ '" style="background-color: black;height: 10px;width: 0%"></div></div><input type="button" id="button'
								+ i + '" value="开始" onclick="startOrStop(' + i
								+ ')"><br>');

		// 检测文件格式
		var fileName =fileList.files[i].name.substr(
						fileList.files[i].name.lastIndexOf(".")).toLowerCase();
		var fileTypeFlag = true;
		if(fileTypeExts!=".*"){
			for (var j = 0; j < fileTypeList.length; j++) {
				if (fileName == fileTypeList[j]) {
					fileTypeFlag = false;
				}
			}
		}else{
			fileTypeFlag = false;
		}
		if (fileTypeFlag) {
			alert('文件类型只能为' + fileTypeExts);
			removeFileQueueId(i);
			break;
		}
		// 检测单个文件大小
		if (fileList.files[i].size > fileSizeLimit) {
			alert('单个文件最大为' + fileSizeLimit / 1024 / 1024 + 'M');
			removeFileQueueId(i);
			break;
		} else {
			notUploadFiles[i] = i;
		}
	}
	if (auto == true) {
		P = notUploadFiles[0];
		$('#button' + P).val('暂停');
		check();// 自动上传第一个文件
	}
}

function startOrStop(i) {

	for (var j = 0; j < notUploadFiles.length; j++) {
		if (notUploadFiles[j] == i) {
			if ($('#button' + i).val() == '开始') {
				$('#button' + i).val('暂停');
				for (var m = 0; m < fileList.files.length; m++) {
					if (m != i) {
						$('#button' + m).val('开始');
					}
				}
				P = i;
				// alert(P);
				setTimeout(check(), 1000);// 上传第i个文件

			} else {
				$('#button' + i).val('开始');
			}
		}
	}
}

function check() {

	file = fileList.files[P];

	var fdd = new FormData();
	var reader = new FileReader();
	// js读取文件，通过返回的result获取MD5码
	var aaa=new Date();
	reader.readAsBinaryString(file);
	reader.onload = function(e) {
		md5 = hex_md5(this.result);
		var ss=new Date()-aaa;
		alert(ss/1000+'秒');
		// alert(md5);
		fdd.append("md5", md5);
		fdd.append("fileSize", file.size);
		start = 0;
		end = LENGTH + start;
		blob = file.slice(start, end);
		fdd.append("mof", blob);
		// 得到断点
		var xhrr = new XMLHttpRequest();
		xhrr.open('POST', server, true);
		xhrr.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				if (this.responseText == "success") {
					nextBlob(P);
				} else {

					end = Number(this.responseText);
					if (start < file.size) {
						nextBlob(P);
					} else {
						nextFile(P);
					}

				}
			}
		}
		xhrr.send(fdd);
	};

}

function up(I) {

	xhr.open('POST', server, true);
	xhr.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {

			if (this.responseText == "success") {
				nextBlob(I);
			} else if (this.responseText == "uploadCompleted") {
				nextFile(I);
				// 上传完成后执行的函数
				uploadCompleted();
			}
		}
	}

	if (I == P) {
		if ($('#button' + I).val() == '开始') {
			xhr.abort();
		}
		// 进度条显示
		pecent = 100 * start / file.size;
		$('#progress' + I).css({
			width : Math.round(pecent) + '%'
		});
		$('#show' + I).html('--' + Math.round(pecent) + '%');
	} else {
		xhr.abort();
	}

	fd = new FormData();
	// 分割文件核心部分slice
	if (end > file.size) {
		blob = file.slice(start, file.size);
		fd.append('uploadCompleted', 'uploadCompleted');
	} else {
		blob = file.slice(start, end);
	}
	fd.append("md5", md5);
	fd.append('mof', blob);
	fd.append('fileName', file.name);
	xhr.send(fd);

}

// 移出进度条和按钮的ID
function removeFileQueueId(ID) {
	$('#progress' + ID).attr("id", "a");
	$('#show' + ID).attr("id", "a");
	$('#button' + ID).attr("onclick", "a");
	$('#button' + ID).attr("id", "a");
}

// 上传下一个切片
function nextBlob(flag) {
	start = end;
	end = start + LENGTH;
	setTimeout('up(' + flag + ')', 1000);
}

// 上传下一个文件
function nextFile(flag) {
	$('#progress' + flag).css({
		width : '100%'
	});
	$('#show' + flag).html('--100%');
	$('#button' + flag).val('开始');

	removeFileQueueId(flag);

	for (var i = 0; i < notUploadFiles.length; i++) {
		if (notUploadFiles[i] == flag) {
			notUploadFiles.splice(i, 1);// 从未完成列表中删除该文件标识
		}
	}

	if (notUploadFiles.length > 0) {
		P = notUploadFiles[0];
		$('#button' + P).val('暂停');
		setTimeout(check(P), 1000);
	}
}
