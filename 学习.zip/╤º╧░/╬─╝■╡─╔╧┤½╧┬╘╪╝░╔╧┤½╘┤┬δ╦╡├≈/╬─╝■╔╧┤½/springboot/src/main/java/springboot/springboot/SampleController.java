package springboot.springboot;

import java.io.File;
import java.io.IOException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.boot.*;
import org.springframework.boot.autoconfigure.*;
import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@Controller
@EnableAutoConfiguration
public class SampleController {

	@RequestMapping(value = "uploadFile", method = RequestMethod.POST, produces = "text/html;charset=utf-8")
	@ResponseBody
	public String uploadFile(@RequestParam("mof") MultipartFile file, HttpServletRequest request,
			HttpServletResponse response) throws IOException {

		response.addHeader("Access-Control-Allow-Origin", "*");
		// 临时文件存储路径为"D:\temporaryFiles\MD5"
		String md5 = request.getParameter("md5");
		String fileName=request.getParameter("fileName");
		String uploadCompleted = request.getParameter("uploadCompleted");

		for(int i=0;;i++){
			File filePath = new File("D:/temporaryFiles/"+md5, String.valueOf(i));
			if(!filePath.exists()){
				file.transferTo(filePath);
				break;
			}        
		}
		
		if ("uploadCompleted".equals(uploadCompleted)) {
			System.out.println(uploadCompleted);
			//合并文件夹
			//new TransFile().transFile("D:/temporaryFiles/"+md5, fileName);
			return "uploadCompleted";
		}
		
		return "success";

	}

	@RequestMapping(value = "equalsMD5", method = RequestMethod.POST, produces = "text/html;charset=utf-8")
	@ResponseBody
	public String equalsMD5(HttpServletRequest request, HttpServletResponse response) throws IOException {

		response.addHeader("Access-Control-Allow-Origin", "*");
		// 临时文件存储路径为"D:\temporaryFiles"
		// 根据文件的MD5码来创建文件夹
		double size = 0;// 已传送文件大小
		String md5 = request.getParameter("md5");
		System.out.println(md5);
		File root = new File("D:/temporaryFiles", md5);
		if (root.exists()) {
			System.out.println("存在");
			File[] files = root.listFiles();
			for (File children : files) {
				size += children.length();
			}
			String str = String.valueOf(size);
			System.out.println(str);
			return str;
		} else {
			System.out.println("创建文件夹");
			root.mkdirs();
			return "success";
		}
	}

	public static void main(String[] args) throws Exception {
		SpringApplication.run(SampleController.class, args);
	}
}
