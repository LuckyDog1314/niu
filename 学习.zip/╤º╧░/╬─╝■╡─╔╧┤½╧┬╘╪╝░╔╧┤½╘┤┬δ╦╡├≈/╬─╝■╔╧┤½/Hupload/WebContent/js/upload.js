//http://localhost:8080/uploadFile
var xhr = new XMLHttpRequest();
var fd;
var file;
const
LENGTH = 1024 * 1024;
var start;
var end;
var blob;
var pecent;
var md5;
var P=0;//第几个
var fileList;

//文件队列
function fileQueue(){
	//var input=$('#file');
	//file = $('#file')[0].files[0];
	start = 0;
	end = LENGTH + start;
	fileList = document.getElementById("file");
	for(var i=0;i<fileList.files.length;i++){
		$('#list').append('<span>'+fileList.files[i].name+'</span><span id="show'+i+'"></span><br><div id="lala" style="float:left;width: 400px;background-color: red;height: 10px;"><div id="progress'+i+'" style="background-color: black;height: 10px;width: 0%"></div></div><input type="button" id="button'+i+'" value="开始" onclick="startOrStop('+i+')"><br>');
	}
	$('#button'+0).val('暂停');
	check();//自动上传第一个文件
}

function startOrStop(i){
	if($('#button'+i).val()=='开始'){
		$('#button'+i).val('暂停');
		for(var m=0;m<fileList.files.length;m++){
			if(m!=i){
				$('#button'+m).val('开始');
			}
		}	
		P=i;
		//alert(P);
		setTimeout(check(),1000);//上传第i个文件
		
	}else{
	  $('#button'+i).val('开始');
	}	
}


function check() {
    
	file=fileList.files[P];
	
	var fdd = new FormData();
	var reader = new FileReader();
	//js读取文件，通过返回的result获取MD5码
	reader.readAsBinaryString(file);
	reader.onload = function(e) {
		md5 = hex_md5(this.result)
		//alert(md5);
		fdd.append("md5", md5);
		// 得到断点
		var xhrr = new XMLHttpRequest();
		xhrr.open('POST', 'http://localhost:8080/equalsMD5', true);
		xhrr.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				if (this.responseText == "success") {
					start = 0;
					end = LENGTH + start;
					setTimeout('up('+P+')', 1000);
				} else {
					// alert(this.responseText);
					start = Number(this.responseText);
					if(start<file.size){
						end = start + LENGTH;
						setTimeout('up('+P+')', 1000);
					}else{
						$('#button'+P).val('开始');
						alert('文件已存在，不需要上传');
						P++;//下一个文件
						if(P<fileList.files.length){
							$('#button'+P).val('暂停');
							setTimeout(check(),1000);
						}	
					}					
				}

			}
		}
		xhrr.send(fdd);
	};

}

function up(I) {
	

		xhr.open('POST', 'http://localhost:8080/uploadFile', true);
		xhr.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {

				if (this.responseText == "success") {
					start = end;
					end = start + LENGTH;
					setTimeout('up('+I+')', 1000);
				} else if (this.responseText == "uploadCompleted") {
					$('#progress'+I).css({
						width :'100%'
					});
					$('#show'+I).html('--100%');
					
					$('#button'+I).val('开始');
					P++;//下一个文件
					if(P<fileList.files.length){
						$('#button'+P).val('暂停');
						setTimeout(check(P),1000);
					}	
				} 
			}
		}
	
  
       // alert('I='+I+'。。。。。'+'P='+P+'。。。。。。。。。start='+start);
        
        if(I==P){
        	if($('#button'+I).val()=='开始'){
        		xhr.abort();
        	}
        	  //进度条显示
    		pecent = 100 *start/ file.size;
    		$('#progress'+I).css({
    			width : Math.round(pecent) + '%'
    		});
    		$('#show'+I).html('--'+Math.round(pecent) + '%');
        }else{
        	xhr.abort();
        }
      
	// 进度条显示
//	xhr.upload.onprogress = function(event) {
//		alert(event);
//		if (ev.lengthComputable) {
//			pecent = 100 * (ev.loaded + start) / file.size;
//			if (pecent > 100) {
//				pecent = 100;
//			}
//
//			$('#progress').css({
//				width : pecent + '%'
//			});
//			$('#show').html(pecent + '%');
//		}
//
//	}

	fd = new FormData();
	// 分割文件核心部分slice
	if (end > file.size) {
		blob = file.slice(start, file.size);
		fd.append('uploadCompleted', 'uploadCompleted');
	} else {
		blob = file.slice(start, end);
	}
	fd.append("md5", md5);
	fd.append('mof', blob);
	fd.append('fileName', file.name);
	xhr.send(fd);

}
