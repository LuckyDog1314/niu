package yuan.java.core;

import java.io.Console;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Scanner;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		// Scanner in = null;
		// try {
		// in = new Scanner(Paths.get("D:\\javacore\\myfile.txt"), "UTF-8");
		// } catch (IOException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }
		// System.out.println(in.nextLine());
		// PrintWriter pr = null;
		// try {
		// pr = new PrintWriter("D:\\javacore\\output.txt", "UTF-8");
		// } catch (FileNotFoundException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// } catch (UnsupportedEncodingException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }
		// pr.write("111111234234324111111111111111111111111");
		// pr.flush();
		// pr.close();
		// ss: for (double x = 0; x != 10; x += 0.1) {
		// System.out.println(x);
		//
		// break ss;
		//
		// }
		// int[] a = { 1, 2, 3, 4, 5 };
		// System.out.println(Arrays.toString(a));
		int[][] odds = new int[10][];
		for (int i = 0; i < 10; i++) {
			odds[i] = new int[i + 1];
		}
		for (int i = 0; i < odds.length; i++) {
			for (int j = 0; j < odds[i].length; j++) {
				odds[i][j] = 1;
			}
		}
		System.out.println(Arrays.deepToString(odds));
	}
}
