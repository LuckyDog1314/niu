var deviceId; //终端设备标识
var licenseNumber; //车牌号
var cose;

//打开得分板
$('.div-relative').click(function(){
	$('#partituro').modal({show:true,backdrop:false,keyboard:false});
	//$(".mask").show();
});
//关闭得分板
$('#button').click(function(){
    $('#partituro').modal('hide');
    $('#partituro').hide();
   });
//$('.mask').click(function(e){
//  var X = Number(e.pageX);
//  var Y = Number(e.pageY);
//	var buttonTop=Number($("#button").offset().top);
//  var buttonLeft=Number($("#button").offset().left);
//  if(Math.abs(buttonLeft+8-X)<15&&Math.abs(buttonTop+10-Y)<15){
//  	$('#partituro').modal('hide');
//      $('#partituro').hide();
//      $('.mask').hide();
//  }
//});

//驾驶行为分析
$("#home_page .main .minute ul li").click(function() {
	$("#home_page .main .minute ul li").removeClass("active");
	cose = $(this).index();
	$("#home_page .main .score").hide();
	$("#home_page .main .score").eq(cose).show();
	$(this).addClass("active");
	if(cose == 0) {
		$(".ago ul .itemm").html("数据模式");
		doPost("driveScore", {
			"deviceId": deviceId,
			"queryDate": $("#queryDateId").val()
		});
	} else if(cose == 1) {
		$(".ago ul .itemm").html("地图模式");
		doPost("violateInfoQuery", {
			"deviceId": deviceId,
			"queryDate": $("#queryDateId").val()
		});
	}
});
//
//// 圆形指示器1。		       
$('#indicatorContainer').radialIndicator({
	radius: 80,
	barColor: '#19c4f9',
	barWidth: 10,
	initValue: 100,
	fontSize: 32,
	roundCorner: false,
	percentage: true
});

$('#indicatorContainer2').radialIndicator({
	radius: 70,
	barColor: '#19c4f9',
	barWidth: 2,
	initValue: 100,
	fontSize: 32,
	roundCorner: false,
	percentage: true
});

//页面加载完毕后执行--------------------------------------------------------------------------------------------------
$(document).ready(function() {
	
		//请求得到驾驶行为违反规则
		doPost("driveScoreRule", {});
	
	$('#frame-vehicle').on('vehicle.selected', function(event, linu, deid) {
		deviceId = deid;
		licenseNumber = linu;
     
        //数据模式与地图模式切换
		if(cose==1) {
			doPost("violateInfoQuery", {
				"deviceId": deviceId,
				"queryDate": $("#queryDateId").val()
			});
		} else {
			doPost("driveScore", {
				"deviceId": deviceId,
				"queryDate": $("#queryDateId").val()
			});
		}
		
		//日期改变时提交表单
		$('#queryDateId').change(function() {
			if($('#queryDateId').attr('sd') != $('#queryDateId').val()) {
				if(cose==1) {
					doPost("violateInfoQuery", {
						"deviceId": deviceId,
						"queryDate": $("#queryDateId").val()
					});
				} else {
					//alert(1);
					doPost("driveScore", {
						"deviceId": deviceId,
						"queryDate": $("#queryDateId").val()
					});
				}
			}
			$('#queryDateId').attr('sd', function() {
				return $('#queryDateId').val();
			});
		});
		
	});
	
});


//----------------------------------------------------------------------------------------------------------------
//驾驶得分查询--------------------------------------------------------------------------------------------------------------------
function driveScoreRequest(request, form) {
	request.head.bid = "BS101";
	request.head.fid = "FN0017";
	request.body.da = {
		deid: form.deviceId,
		quda: form.queryDate
	}

}

function driveScoreResponse(response) {
	if(response.body.com.reco == "0") {
		//幻灯片初始化------------------------------------------------------------------------------------
		$(".swiper-wrapper").html("");
		//幻灯片
		var swiper = new Swiper('.swiper-container', {
			pagination: '.swiper-pagination',
			nextButton: '.swiper-button-next',
			prevButton: '.swiper-button-prev',
			slidesPerView: 1,
			paginationClickable: true,
			spaceBetween: 30,
			loop: true
		});
		//-----------------------------------------------------------------------------------------------
		if(response.body.da) {
			var data = eval(response.body.da);
			var drsc = data.drsc;
			if(data.vide == null) {
				drsc = 100;
			}
			var radialObj = $('#indicatorContainer').data('radialIndicator'); //获取圆形指示器的对象
			radialObj.value(drsc); // 设置刻度值
			var radialObj2 = $('#indicatorContainer2').data('radialIndicator'); //获取圆形指示器的对象
			radialObj2.value(drsc); // 设置刻度值

			$("#myModalLabel").html("<div style='color:#b0b0b0;'>满分100分，得分<div  style='color:#F00;display:inline;'>" + drsc + "</div>分</div>");

			//幻灯片开始---------------------------------------------------------------------------------------

			var str = "";
			var m = 0;
			var n = 0;
			if(response.body.da.vide != null) {
				for(var i = 0; i < response.body.da.vide.length; i++) {
					var vide = eval(data.vide[i]); //违反详情

					if(i % 6 == 0) {
						str += "<div class='swiper-slide wake'>";
						m = i + 5;
					}
					if(i % 3 == 0) {
						str += "<div class='akceli'>";
						n = i + 2;
					}
					str += "<div class='plus'>" +
						"<ul class='list-group' style='width:100%';'>" +
						"<li ><img src='img/" + vide.vityi + ".png'></li>" +
						"<li style='width:20%;font-size:10px;'>" + vide.vityn + "</li>" +
						"<li class='one'style='width:2%;font-size:10px;'>" + vide.viti + "</li>" +
						"<li style='font-size:10px;'>次</li>" +
						"</ul>" +
						"</div>";

					if(n == i || (n > i && i == response.body.da.vide.length - 1)) {
						str += "</div>";
					}
					if(m == i || (m > i && i == response.body.da.vide.length - 1)) {
						str += "</div>";
					}
				}
			}

			$(".swiper-wrapper").html(str);
			//幻灯片
			var swiper = new Swiper('.swiper-container', {
				pagination: '.swiper-pagination',
				nextButton: '.swiper-button-next',
				prevButton: '.swiper-button-prev',
				slidesPerView: 1,
				paginationClickable: true,
				spaceBetween: 30,
				loop: true
			});
			

			//幻灯片结束----------------------------------------------------------------------------------------
			//弹出框开始------------------------------------------------------------------------------------------
			var tbody = $("#driveScoreTable tbody");
			var vides = eval(response.body.da.vide);

			//表格初始化
			var ss = 0;
			var sss = tbody.find('td:eq(' + ss + ')').text();
			while(sss != "") {
				var mm = ss;
				var nn = ss;
				mm = mm + 2;
				nn = nn + 3;
				tbody.find('td:eq(' + mm + ')').html(0);
				tbody.find('td:eq(' + nn + ')').html(0);

				ss = ss + 4;
				sss = tbody.find('td:eq(' + ss + ')').text();
			}
			//表格赋值
			var ii = 0;
			var vityn = tbody.find('td:eq(' + ii + ')').text();
			while(vityn != "") {
				for(var j = 0; j < vides.length; j++) {
					if(vityn == vides[j].vityn) {
						var x = ii;
						var y = ii;
						x = x + 2;
						y = y + 3;
						tbody.find('td:eq(' + x + ')').html(vides[j].viti);
						tbody.find('td:eq(' + y + ')').html("<div style='color:#F00;'>-" + vides[j].pode + "</div>");
						var trLine = ii / 4;
						var upTop = tbody.find('tr:eq(' + trLine + ')').fadeOut().fadeIn();
						var table = $("#driveScoreTable");
						table.prepend(upTop);
						vides.splice(j, 1);
					}
				}
				ii = ii + 4;
				vityn = tbody.find('td:eq(' + ii + ')').text();
			}
			//弹出框结束---------------------------------------------------------------------------------------
		}
	} else {
		showWarningMessageDialog(response.body.com.reme);
	}
}

function driveScoreException(exception, code, status) {
	showWarningMessageDialog("请求发送失败");
}
//驾驶评分规则查询----------------------------------------------------------------------------------------------------------------
function driveScoreRuleRequest(request) {
	request.head.bid = "BS101";
	request.head.fid = "FN0018";
}

function driveScoreRuleResponse(response) {
	if(response.body.com.reco == "0") {
		if(response.body.da) {
			var htmlStr = "";
			var datas = eval(response.body.da);
			for(var i = 0; i < datas.length; i++) {
				var data = datas[i];
				htmlStr += "<tr ><td style='color:#b0b0b0;'>" + data.vityn + "</td>";
				htmlStr += "<td style='color:#b0b0b0;'>" + data.poeat + "</td>";
				htmlStr += "<td style='color:#b0b0b0;'>" + 0 + "</td>";
				htmlStr += "<td style='color:#b0b0b0;'>" + 0 + "</td></tr>";
			}
			//    alert(1);
			$("#driveScoreTable tbody").html(htmlStr);
		}
	} else {
		showWarningMessageDialog(response.body.com.reme);
	}
}

function driveScoreRuleException(exception, code, status) {
	showWarningMessageDialog("请求发送失败");
}


var infoWindow = new AMap.InfoWindow({
	offset: new AMap.Pixel(0, -30)
});

function markerClick(e) {
	infoWindow.setContent(e.target.content);
	infoWindow.open(map, e.target.getPosition());
}

//违反信息查询----------------------------------------------------------------------------------------------------------------
function violateInfoQueryRequest(request, form) {
	request.head.bid = "BS101";
	request.head.fid = "FN0010";

	request.body.da = {
		deid: form.deviceId,
		quda: form.queryDate
	}
}

function violateInfoQueryResponse(response) {

	doPost("queryCarHistoricalTrack", {

	});
	map.clearMap();
	if(response.body.com.reco == "0") {
		if(response.body.da) {
			var datas = eval(response.body.da);

			for(var i = 0; i < datas.length; i++) {

				var data = datas[i];

				var marker = new AMap.Marker({
					map: map,
					position: new Array(data.gacob.lon, data.gacob.lat)
				});
				var beti = new Date(data.beti);

				marker.content = '<div  style="line-height: 30PX ;font-size:14px;padding-left:2em;padding-top:0.5em;line-height:35 px;"><table><tr><td style="white-space:nowrap;"><div style="width: 4em;letter-spacing:0.5em;display:inline;">车牌号</div></td><td>：' +
					licenseNumber + '</td></tr><tr><td style="white-space:nowrap;"><div style="width: 4em;display:inline;">事件名称</div></td><td>：' +
					data.vityn + '</td></tr><tr><td style="white-space:nowrap;"><div style="width: 4em;letter-spacing:2em;display:inline;">开始</div></td><td>：' +
					beti.getHours() + ":" + beti.getMinutes() + ":" + beti.getSeconds() + '</td></tr><tr><td style="white-space:nowrap;"><div  style="width: 4em;display:inline;">持续时间</div></td><td>：' +
					"" + '</td></tr><tr><td style="white-space:nowrap;"><div style="width: 4em;letter-spacing:0.5em;display:inline;">最大值</div></td><td>：' +
					"" + '</td></tr><tr><td style="white-space:nowrap;"><div  style="width: 4em;display:inline;">事件时间</div></td><td>：' +
					beti.getFullYear() + "-" + beti.getMonth() + "-" + beti.getDate() + '</td></tr><tr><td style="white-space:nowrap;"><div style="width: 4em;display:inline;">事件地址</div></td><td>：' +
					data.adbe + '</td></tr></table></div>';

				marker.on('click', markerClick);
				marker.emit('click', {
					target: marker
				});

				if(i == datas.length - 1) {
					infoWindow.close(map, new Array(data.gacob.lon, data.gacob.lat));
				}
			}
			//map.setFitView();
		}
	} else {
		showWarningMessageDialog(response.body.com.reme);
	}
}

function violateInfoQueryException(exception, code, status) {
	showWarningMessageDialog("请求发送失败");
}

//车辆历史轨迹每页显示条数
var carHistoricalTrackPageSize = 1000;
//车辆历史轨迹每页显示当前页数
var carHistoricalTrackPageNumber = 1;
//车辆行程坐标每页显示条数
var carTravelCoordinatePageSize = 1000;
//车辆行程坐标每页显示当前页数
var carTravelCoordinatePageNumber = 1;
var carTravelCoordinateDeid;
//车辆行程坐标使用百度坐标显示
const COORDINATE_FORMAT_BAIDU = 1;
//车辆历史轨迹使用高德坐标显示
const COORDINATE_FORMAT_GAODE = 2;

/**
   * 车辆历史轨迹查询
   * @param request 请求参数
   * @param from 表单 from
   */
function queryCarHistoricalTrackRequest(request, from) {
	//请求体头部
	request.head = {
		bid: "BS101",
		fid: "FN0009"
	}

	//请求data部
	request.body.da = {
		deid: deviceId,
		quda: $("#queryDateId").val(),
		cofo: COORDINATE_FORMAT_GAODE,
		panu: carHistoricalTrackPageNumber,
		pasi: carHistoricalTrackPageSize
	}
}

/**
   * 车辆历史轨迹查询返回
   * @param response 返回结果
   */
function queryCarHistoricalTrackResponse(response) {

	if(response.body.da != null && response.body.da.length > 0) {

		var historicalTracks = response.body.da.length;
		if(carHistoricalTrackPageSize < historicalTracks + 1) {
			//如果返回结果条数加1大于每页显示条数，说明还有下一页数据，当前页数加1
			carHistoricalTrackPageNumber++;
			//获取剩下的车辆行程坐标
			queryCarHistoricalTrackRequest();
		}
		//初始化要描绘的历史轨迹线
		lineArr = [];
		//循环获取要描绘的历史轨迹点
		for(var i = 0; i < response.body.da.length; i++) {
			var position = new Array(response.body.da[i].lon, response.body.da[i].lat);
			//将获取的历史轨迹添加到要绘制的轨迹数组中
			lineArr.push(position);
		}
		//绘制车辆历史轨迹
		drawPolyline();
		//初始化全局历史轨迹
		initPlayedHistoricalTrack();
		//车辆历史轨迹数据
		playedHistoricalTrackData = response.body.da;

	} else {
		//没有车辆历史轨迹数据返回时显示
		showWarningMessageDialog(response.body.com.reme);
	}
}

/**
   * 车辆历史轨迹查询异常
   * @param exception 异常对象
   * @param code 返回code
   * @param status 状态
   */
function queryCarHistoricalTrackException(exception, code, status) {
	showWarningMessageDialog("请求发送失败");
}

/**
 * Created by Administrator on 2016/8/15.
 * 历史轨迹地图操作
 */
//
var map, geolocation, lnglatXY;
var car_icon = new AMap.Icon({image: 'img/caricon.png',//24px*24px
    //icon可缺省，缺省时为默认的蓝色水滴图标，
    size: new AMap.Size(73, 35),
//        imageOffset: new AMap.Pixel(-28, 0)//相对于大图的取图位置
});
var start_point_icon = new AMap.Icon({image: 'img/outset.png',//24px*24px
    //icon可缺省，缺省时为默认的蓝色水滴图标，
    size: new AMap.Size(53, 74),
//        imageOffset: new AMap.Pixel(-28, 0)//相对于大图的取图位置
});
var terminal_point_icon = new AMap.Icon({image: 'img/end.png',//24px*24px
    //icon可缺省，缺省时为默认的蓝色水滴图标，
    size: new AMap.Size(53, 74),
//        imageOffset: new AMap.Pixel(-28, 0)//相对于大图的取图位置
});
//加载地图，调用浏览器定位服务
var map = new AMap.Map('car_map1', {
    resizeEnable: true
});
var lineArr = [];

function drawPolyline() {
    var polyline = new AMap.Polyline({
        path: lineArr,          //设置线覆盖物路径
        strokeColor: "#3366FF", //线颜色
        strokeOpacity: 1,       //线透明度
        strokeWeight: 5,        //线宽
        strokeStyle: "solid",   //线样式
        strokeDasharray: [10, 5] //补充线样式
    });
    markerStart = new AMap.Marker({
        map: map,
        icon: start_point_icon,
        offset: new AMap.Pixel(-27, -75),
        position: lineArr[0]
    });
  
    markerTerminal = new AMap.Marker({
        map: map,
        icon: terminal_point_icon,
        offset: new AMap.Pixel(-27, -75),
        position: lineArr[lineArr.length - 1]
    });
    polyline.setMap(map);
    map.setFitView();
}
/**
 * 初始化全局历史轨迹
 */
function initPlayedHistoricalTrack() {
    removeplayedHistoricalTrack(playedHistoricalTrack);
    playedHistoricalTrack = [];
    playedHistoricalTrackData = [];
}

//历史轨迹数据
var playedHistoricalTrack = [];
//历史轨迹数据
var playedHistoricalTrackData = [];

function removeplayedHistoricalTrack(playedHistoricalTrack) {
    map.remove(playedHistoricalTrack);
}