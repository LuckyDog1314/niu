package jndi;

import java.io.Console;
import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		// Scanner in = new Scanner(System.in);
		// System.out.println("name");
		// String name = in.nextLine();
		// System.out.println("age");
		// String age = name + in.nextLine();
		// System.out.println(age);
		Console cons = System.console();
		String username = cons.readLine("User name: ");
		
	}
}
