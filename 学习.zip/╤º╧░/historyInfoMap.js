/**
 * Created by Administrator on 2016/8/15.
 * 历史轨迹地图操作
 */
//
var map, geolocation, lnglatXY;
var car_icon = new AMap.Icon({
    image: 'img/caricon.png',//24px*24px
    //icon可缺省，缺省时为默认的蓝色水滴图标，
    size: new AMap.Size(73, 35),
//        imageOffset: new AMap.Pixel(-28, 0)//相对于大图的取图位置
});
var start_point_icon = new AMap.Icon({
    image: 'img/outset.png',//24px*24px
    //icon可缺省，缺省时为默认的蓝色水滴图标，
    size: new AMap.Size(53, 74),
//        imageOffset: new AMap.Pixel(-28, 0)//相对于大图的取图位置
});
var terminal_point_icon = new AMap.Icon({
    image: 'img/end.png',//24px*24px
    //icon可缺省，缺省时为默认的蓝色水滴图标，
    size: new AMap.Size(53, 74),
//        imageOffset: new AMap.Pixel(-28, 0)//相对于大图的取图位置
});
//加载地图，调用浏览器定位服务
map = new AMap.Map('car_map1', {
    resizeEnable: true
});
var lineArr = [];
/*map.plugin('AMap.Geolocation', function () {
 geolocation = new AMap.Geolocation({
 enableHighAccuracy: true,//是否使用高精度定位，默认:true
 timeout: 10000,          //超过10秒后停止定位，默认：无穷大
 buttonOffset: new AMap.Pixel(10, 20),//定位按钮与设置的停靠位置的偏移量，默认：Pixel(10, 20)
 zoomToAccuracy: true,      //定位成功后调整地图视野范围使定位位置及精度范围视野内可见，默认：false
 showCircle: false,
 buttonPosition: 'RB'
 });
 map.addControl(geolocation);
 geolocation.getCurrentPosition();
 AMap.event.addListener(geolocation, 'complete', onComplete);//返回定位信息
 AMap.event.addListener(geolocation, 'error', onError);      //返回定位出错信息
 });
 //解析定位结果
 function onComplete(data) {
 /!*   var str = ['定位成功'];
 str.push('经度：' + data.position.getLng());
 str.push('纬度：' + data.position.getLat());
 str.push('精度：' + data.accuracy + ' 米');
 str.push('是否经过偏移：' + (data.isConverted ? '是' : '否'));
 document.getElementById('tip').innerHTML = str.join('<br>');*!/
 lnglatXY = [data.position.getLng(), data.position.getLat()]; //已知点坐标
 // regeocoder();
 }
 //解析定位错误信息
 function onError(data) {
 document.getElementById('tip').innerHTML = '定位失败';
 }*/
/*
 注释掉地图点击事件
 map.on('click', function (e) {
 var location = new Array(e.lnglat.getLng(), e.lnglat.getLat());
 lineArr.push(location);
 alert('您在[ ' + e.lnglat.getLng() + ',' + e.lnglat.getLat() + ' ]的位置点击了地图！');
 });*/
/*function regeocoder() {  //逆地理编码
 var geocoder = new AMap.Geocoder({
 radius: 1000,
 extensions: "all"
 });
 geocoder.getAddress(lnglatXY, function(status, result) {
 if (status === 'complete' && result.info === 'OK') {
 geocoder_CallBack(result);
 }
 });
 /!*var marker = new AMap.Marker({  //加点
 map: map,
 position: lnglatXY
 });
 map.setFitView();*!/
 }
 function geocoder_CallBack(data) {
 var address = data.regeocode.formattedAddress; //返回地址描述
 document.getElementById("curr_location").innerHTML = address;
 }*/
function drawPolyline() {
    var polyline = new AMap.Polyline({
        path: lineArr,          //设置线覆盖物路径
        strokeColor: "#3366FF", //线颜色
        strokeOpacity: 1,       //线透明度
        strokeWeight: 5,        //线宽
        strokeStyle: "solid",   //线样式
        strokeDasharray: [10, 5] //补充线样式
    });
    markerStart = new AMap.Marker({
        map: map,
        icon: start_point_icon,
        offset: new AMap.Pixel(-27, -75),
        position: lineArr[0]
    });
    /*var lineArrlength=lineArr.length;
     var terminal=lineArrlength-1;*/
    markerTerminal = new AMap.Marker({
        map: map,
        icon: terminal_point_icon,
        offset: new AMap.Pixel(-27, -75),
        position: lineArr[lineArr.length - 1]
    });
    polyline.setMap(map);
    map.setFitView();
}
/**
 * 初始化全局历史轨迹
 */
function initPlayedHistoricalTrack() {
    player_timer = null;
    player_index = 0;
    removeplayedHistoricalTrack(playedHistoricalTrack);
    playedHistoricalTrack = [];
    // playedHistoricalTrackData = [];
}
//历史轨迹播放Timer
var player_timer;
//当前播放历史轨迹索引
var player_index = 0;
//历史轨迹数据
var playedHistoricalTrack = [];
//历史轨迹数据
var playedHistoricalTrackData = [];
// 暂停播放历史轨迹flag
var pause_player = false;
function play_historical_track(arrHistoricalTrack) {
    if (pause_player) {
        return;
    }
    removeplayedHistoricalTrack(playedHistoricalTrack);
    player_timer = setTimeout("play_historical_track(playedHistoricalTrackData)", 3000);
    var location = playedHistoricalTrackData[player_index];
    drawMarker(location);
    player_index = player_index + 1;
    if (player_index == playedHistoricalTrackData.length) {
        suspend_historical_track();
        $("#home_page .main .transmit .right ul .cast2").prev(".cast1").removeClass("active");
    }
}

function suspend_historical_track() {
    //清空Timer对象
    clearTimeout(player_timer);
}

function drawMarker(historicalTrack) {
    //添加点标记，并使用自己的icon
    var carHistoricalTrack = historicalTrack;
    marker = new AMap.Marker({
        map: map,
        icon: car_icon,
        angle: carHistoricalTrack.di,
        autoRotation: true,
        offset: new AMap.Pixel(-12, -24),
        position: new Array(carHistoricalTrack.lon, carHistoricalTrack.lat),
    });
    showHistoricalTrackInfo(carHistoricalTrack);
    playedHistoricalTrack.push(marker);
    map.panTo(AMap.LngLat(carHistoricalTrack.lon, carHistoricalTrack.lat));
    // map.setFitView();
}
function showHistoricalTrackInfo(historicalTrackInfo) {
    $("#historical_track_info").css("display", "block");
    $(".historical_track_info .historical_track_info_time").html(historicalTrackInfo.dacot);
    $(".historical_track_info .historical_track_info_rpm").html(historicalTrackInfo.rpm + "转/分钟");
    $(".historical_track_info .historical_track_info_sp").html(historicalTrackInfo.sp + "公里/小时");
}
function removeplayedHistoricalTrack(playedHistoricalTrack) {
    map.remove(playedHistoricalTrack);
}
