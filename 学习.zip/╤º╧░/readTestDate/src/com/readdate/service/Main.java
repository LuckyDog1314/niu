package com.readdate.service;

import java.util.ArrayList;

import com.readdate.bean.TestData;

public class Main {

	public static void main(String[] args) {
		try {
			ArrayList<TestData> testDatas = ReadData.readExcel("D:\\platform-document\\40_测试\\10_UT\\011_账户管理\\功能测试用例（011_0009）_获取登陆码.xlsx");
			ArrayList<String> arr = ReadData.requestData(testDatas);
			for (String string : arr) {
				System.out.println(string);
			}
			ArrayList<String> arr2 = ReadData.dbData(testDatas);
			for (String string : arr2) {
				System.out.println(string);
			}
			ReadData.useCase(testDatas);
//			ArrayList<StringBuffer> arr3 = ReadData.useCase(testDatas);
//			for (StringBuffer stringBuffer : arr3) {
//				System.out.println(stringBuffer.toString());
//			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
