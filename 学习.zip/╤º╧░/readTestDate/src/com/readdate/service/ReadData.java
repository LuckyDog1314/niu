package com.readdate.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import com.readdate.bean.TestData;
import com.readdate.utils.ExcelUtils;
import com.readdate.utils.ExcelUtils.CallBackExcelSingleRow;

/**
 * 读取Excel表中的数据
 * @author shengtengfei
 *
 */
public class ReadData {
	
	/**
	 * 读取Excel表中的数据
	 */
	public static ArrayList<TestData> readExcel(String path)throws Exception{
		int beginRow = 0;
		int beginLine = 4;
		InputStream input = new FileInputStream(new File(path));
		InputStream input2 = new FileInputStream(new File(path));
		int endLine = ExcelUtils.getRowNumber(input2);
		ArrayList<TestData> arrayList = new ArrayList<TestData>();
		ExcelUtils.readExcel(input, ExcelUtils.EXCEL_FORMAT_XLSX, 1, new CallBackExcelSingleRow() {
			
			public void readRow(List<String> rowContent, int rowIndex) {
				if(rowIndex >= beginLine && rowIndex <= endLine){
					String str = String.valueOf(rowContent.get(beginRow).length());
					if(str.equals("1")){
						TestData testData = new TestData();
						String number = rowContent.get(beginRow).trim();
						testData.setNumber(number);
						String outLine = rowContent.get((beginRow + 1)).trim();
						testData.setOutLine(outLine);
						String elaborate = rowContent.get((beginRow + 2)).trim();
						testData.setElaborate(elaborate);
						String classify = rowContent.get((beginRow + 3)).trim();
						testData.setClassify(classify);
						String requestHead = rowContent.get((beginRow + 4)).trim();
						testData.setRequestHead(requestHead);
						String requestBody = rowContent.get((beginRow + 5)).trim();
						testData.setRequestBody(requestBody);
						String condition = rowContent.get((beginRow + 6)).trim();
						testData.setCondition(condition);
						String dbData = rowContent.get((beginRow + 7)).trim();
						testData.setDbData(dbData);
						String responseHead = rowContent.get((beginRow + 8)).trim();
						testData.setResponseHead(responseHead);
						String responseBody = rowContent.get((beginRow + 9)).trim();
						testData.setResponseBody(responseBody);
						arrayList.add(testData);
					}
				}
			}
		});	
		return arrayList;
	}

	/**
	 * MongoDB模拟数据
	 * @param testDatas Excel表中读取到的数据
	 * @return
	 */
	public static ArrayList<String> dbData(ArrayList<TestData> testDatas){
		ArrayList<String> arrayList = new ArrayList<>();
		arrayList.add("#FN00测试DB数据\n");
		for (TestData testData : testDatas) {
			arrayList.add(("FN0000_test0"+testData.getNumber()+"="+"{"+testData.getDbData()+"}"+"\n").replaceAll("\r|\n", "").replaceAll(" ", ""));
		}
		return arrayList;
	}
	
	/**
	 * 模拟请求数据
	 * @param testDatas Excel表中读取到的数据
	 * @return
	 */
	public static ArrayList<String> requestData(ArrayList<TestData> testDatas){
		ArrayList<String> arrayList = new ArrayList<>();
		arrayList.add("#FN00请求数据\n");
		for (TestData testData : testDatas) {
			arrayList.add(("FN0000_test0"+String.format("%02d", Integer.valueOf(testData.getNumber()))+"="+"{"+testData.getRequestHead()+testData.getRequestBody()+"}"+"\n").replaceAll("\r|\n", "").replaceAll(" ", ""));
		}
		return arrayList;
	}
	
	public static void useCase(ArrayList<TestData> testDatas) throws Exception{
		StringBuffer headBuffer = new StringBuffer();
		headBuffer.append("@RunWith(SpringRunner.class)\n");
		headBuffer.append("@SpringBootApplication\n");
		headBuffer.append("@PropertySource(value = { "+"application_am_test.properties"+"," + "request_data_am.properties"+","+ "db_data_am.properties" +"})\n");
		headBuffer.append("public class FN0000Test extends UnitTest {\n");
		headBuffer.append("// 测试功能服务\n");
		headBuffer.append("@Autowired\n");
		headBuffer.append("private AMFN00 fn00;\n");
		headBuffer.append("@Autowired\n");
		headBuffer.append("private MDBTemplateAM mdbTemplateAM;\n");
		headBuffer.append("// 测试请求数据\n");
		
		for (TestData testData : testDatas) {
			headBuffer.append("@Value(\"${FN0000_test"+String.format("%02d", Integer.valueOf(testData.getNumber()))+"}\")\n");
			headBuffer.append("private String reqJsonTest"+String.format("%02d", Integer.valueOf(testData.getNumber()))+";\n");
		}
		headBuffer.append("\n// 测试DB数据\n");
		for (TestData testData : testDatas) {
			headBuffer.append("@Value(\"${FN0000_test"+String.format("%02d", Integer.valueOf(testData.getNumber()))+"}\")\n");
			headBuffer.append("private String reqJsonTest"+String.format("%02d", Integer.valueOf(testData.getNumber()))+";\n");
		}
		
		headBuffer.append("/**\n");
		headBuffer.append("* 将模拟对象注入到service相应的对象中\n");
		headBuffer.append("* @throws Exception\n");
		headBuffer.append("*/\n");
		headBuffer.append("@Before\n");
		headBuffer.append("public void setUp() throws Exception {\n");
		headBuffer.append("}\n");
		
		StringBuffer buffer = new StringBuffer();
		for (TestData testData : testDatas) {
			buffer.append("/**\n");
			buffer.append("*"+testData.getOutLine()+"\n");
			buffer.append("*"+testData.getElaborate()+"\n");
			buffer.append("*/\n");
			buffer.append("@Test");
			buffer.append("public void test_"+String.format("%02d", Integer.valueOf(testData.getNumber()))+"() throws Exception {\n");
			buffer.append("}\n");
		}
		String str = headBuffer.toString()+buffer.toString();
		byte[] b = str.getBytes();
		FileOutputStream out = new FileOutputStream("D:\\JavaBean\\Test.java");
		out.write(b);
		out.close();
	}
}
