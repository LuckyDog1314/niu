package test.adapterPattern;

public class AudioPlayer implements MediaPlayer {

	public void play(String audioType, String fileName) {
		// TODO Auto-generated method stub
		// 播放MP3音乐文件的内部支持
		if ("mp3".equalsIgnoreCase(audioType)) {
			System.out.println("Play mp3 file.Name:" + fileName);
		}
		// mediaAdapter提供了播放其他文件格式的支持
		else if ("vlc".equalsIgnoreCase(audioType) || "mp4".equalsIgnoreCase(audioType)) {
			MediaAdapter mediaAdapter = new MediaAdapter(audioType);
			mediaAdapter.play(audioType, fileName);
		} else {
			System.out.println("Invalid media." + audioType + "format not supported");
		}
	}

}
