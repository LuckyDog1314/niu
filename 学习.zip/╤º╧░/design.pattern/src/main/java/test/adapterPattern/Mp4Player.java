package test.adapterPattern;

public class Mp4Player implements AdvancedMediaPlayer {

	public void playVlc(String fileName) {
		// TODO Auto-generated method stub

	}

	public void playMp4(String fileName) {
		// TODO Auto-generated method stub
		System.out.println("Playing mp4 file.Name:" + fileName);
	}

}
