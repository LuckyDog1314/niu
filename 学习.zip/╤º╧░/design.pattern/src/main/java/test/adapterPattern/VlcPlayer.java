package test.adapterPattern;

public class VlcPlayer implements AdvancedMediaPlayer {

	public void playVlc(String fileName) {
		// TODO Auto-generated method stub
		System.out.println("Playing vlc file.Name:" + fileName);
	}

	public void playMp4(String fileName) {
		// TODO Auto-generated method stub

	}

}
