package test.single;

public enum Singleton6 {

	INSTANCE;
	public void whateverMethod() {
		System.out.println(123);
	}
}
