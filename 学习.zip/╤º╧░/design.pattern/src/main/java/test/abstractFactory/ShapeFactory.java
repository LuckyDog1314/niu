package test.abstractFactory;

public class ShapeFactory extends AbstractFactory {

	@Override
	Shape getShape(String shapeType) {
		// TODO Auto-generated method stub
		if ("Circle".equalsIgnoreCase(shapeType)) {
			return new Circle();
		} else if ("Square".equalsIgnoreCase(shapeType)) {
			return new Square();
		} else if ("Rectangle".equalsIgnoreCase(shapeType)) {
			return new Rectangle();
		}
		return null;
	}

	@Override
	Color getColor(String colorType) {
		// TODO Auto-generated method stub
		return null;
	}

}
