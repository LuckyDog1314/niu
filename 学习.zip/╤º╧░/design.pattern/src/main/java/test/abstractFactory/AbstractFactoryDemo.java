package test.abstractFactory;

public class AbstractFactoryDemo {

	public static void main(String[] args) {
		AbstractFactory shape = FactoryProducer.getAbstractFactory("SHAPE");
		Shape rectangle = shape.getShape("Rectangle");
		rectangle.draw();

		AbstractFactory color = FactoryProducer.getAbstractFactory("COLOR");
		Color red = color.getColor("Red");
		red.fill();
	}

}
