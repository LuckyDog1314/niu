package test.abstractFactory;

public interface Shape {

	public void draw();

}
