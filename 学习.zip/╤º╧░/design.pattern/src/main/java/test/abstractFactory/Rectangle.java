package test.abstractFactory;

public class Rectangle implements Shape {

	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("长方形");
	}

}
