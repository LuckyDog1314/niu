package test.abstractFactory;

public class Green implements Color {

	public void fill() {
		// TODO Auto-generated method stub
		System.out.println("绿色");
	}

}
