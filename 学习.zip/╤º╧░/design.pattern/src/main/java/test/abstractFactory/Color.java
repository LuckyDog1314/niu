package test.abstractFactory;

public interface Color {
	public void fill();
}
