package test.abstractFactory;

public class ColorFactory extends AbstractFactory {

	@Override
	Shape getShape(String shapeType) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	Color getColor(String colorType) {
		// TODO Auto-generated method stub
		if ("Red".equalsIgnoreCase(colorType)) {
			return new Red();
		} else if ("Blue".equalsIgnoreCase(colorType)) {
			return new Blue();
		} else if ("Green".equalsIgnoreCase(colorType)) {
			return new Green();
		}

		return null;
	}

}
