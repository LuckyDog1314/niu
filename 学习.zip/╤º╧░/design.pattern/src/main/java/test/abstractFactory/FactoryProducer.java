package test.abstractFactory;

public class FactoryProducer {

	public static AbstractFactory getAbstractFactory(String choice) {
		if ("Shape".equalsIgnoreCase(choice)) {
			return new ShapeFactory();
		}
		if ("Color".equalsIgnoreCase(choice)) {
			return new ColorFactory();
		}
		return null;
	}

}
