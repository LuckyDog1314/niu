package test.abstractFactory;

public class Red implements Color {

	public void fill() {
		// TODO Auto-generated method stub
		System.out.println("红色");
	}

}
