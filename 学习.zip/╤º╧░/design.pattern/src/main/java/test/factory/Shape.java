package test.factory;

public interface Shape {

	public void draw();

}
