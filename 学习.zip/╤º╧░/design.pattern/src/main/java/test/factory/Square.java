package test.factory;

public class Square implements Shape {

	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("正方形");
	}

}
