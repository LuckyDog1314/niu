package test.factory;

public class Circle implements Shape {

	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("圆形");
	}

}
