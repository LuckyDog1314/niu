package test.buliderPattren;

public class Bottle implements Packing {

	public String pack() {
		// TODO Auto-generated method stub
		return "薯条";
	}

}
