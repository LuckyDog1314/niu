package test.buliderPattren;

public interface Packing {

	public String pack();

}
