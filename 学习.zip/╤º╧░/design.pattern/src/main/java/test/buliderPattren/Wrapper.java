package test.buliderPattren;

public class Wrapper implements Packing {

	public String pack() {
		// TODO Auto-generated method stub
		return "辣条";
	}

}
