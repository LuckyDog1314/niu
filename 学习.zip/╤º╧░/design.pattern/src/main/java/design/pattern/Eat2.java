package design.pattern;

public class Eat2 implements Eat {

	public void eat() {
		// TODO Auto-generated method stub
		System.out.println("不吃屎的");
	}

}
