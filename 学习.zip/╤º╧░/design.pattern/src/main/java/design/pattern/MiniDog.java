package design.pattern;

public class MiniDog extends Dog {

//	public MiniDog() {
//		// TODO Auto-generated constructor stub
//		eat = new Eat2();
//	}

	@Override
	public void ear() {
		// TODO Auto-generated method stub
		System.out.println("这是一个短耳朵狗");
	}

}
