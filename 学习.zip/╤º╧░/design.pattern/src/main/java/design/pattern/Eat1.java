package design.pattern;

public class Eat1 implements Eat {

	public void eat() {
		// TODO Auto-generated method stub
		System.out.println("吃屎的");
	}

}
