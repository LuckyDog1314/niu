package design.pattern;

public class Test {

	public static void main(String[] args) {
		MiniDog min = new MiniDog();
		min.setEat(new Eat1());
		min.swimming();
		min.eat.eat();
		min.ear();
	}

}
