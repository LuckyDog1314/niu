package design.pattern;

public interface Eat {

	public void eat();
}
