package design.pattern;

public abstract class Dog {

	Eat eat;

	public void swimming() {
		// TODO Auto-generated method stub
		System.out.println("所有的狗都会游泳");
	}

	public abstract void ear();

	public void eat() {
		eat.eat();// 由于是接口,会根据继承类实现的方式,而调用相应的方法
	}

	public void setEat(Eat eat) {
		this.eat = eat;
	}
}
