package cn.sh.changxing.bs.vrmt.log;

import org.bson.Document;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import ch.qos.logback.core.UnsynchronizedAppenderBase;

public abstract class MongoDBAppenderBase<E> extends UnsynchronizedAppenderBase<E> {

	private String username;
	private String password;
	private String port;
	private String url;
	private String databasename;
	private String admin;
	private String collection;
	private MongoCollection<Document> doc;
	private MongoClient mongoClient;
	private MongoClientURI uri;

	@Override
	public void start() {
		// TODO Auto-generated method stub
		connectionMongoDB();
		super.start();
	}

	private void connectionMongoDB() {

		uri = new MongoClientURI("mongodb://" + username + ":" + password + "@" + url + ":" + port + "/" + admin);
		mongoClient = new MongoClient(uri);
		MongoDatabase database = mongoClient.getDatabase(databasename);
		doc = database.getCollection(collection);

	}

	protected abstract Document toMongoDocument(E event);

	@Override
	protected void append(E eventObject) {
		// TODO Auto-generated method stub
		Document document = toMongoDocument(eventObject);
		if (document != null) {
			doc.insertOne(document);
		}
	}

	@Override
	public void stop() {
		// TODO Auto-generated method stub
		if (mongoClient != null) {
			mongoClient.close();
		}
		super.stop();
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPort() {
		return port;
	}

	public void setPort(String port) {
		this.port = port;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getDatabasename() {
		return databasename;
	}

	public void setDatabasename(String databasename) {
		this.databasename = databasename;
	}

	public String getAdmin() {
		return admin;
	}

	public void setAdmin(String admin) {
		this.admin = admin;
	}

	public String getCollection() {
		return collection;
	}

	public void setCollection(String collection) {
		this.collection = collection;
	}
}
