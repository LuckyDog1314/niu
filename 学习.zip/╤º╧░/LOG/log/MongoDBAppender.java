package cn.sh.changxing.bs.vrmt.log;


import java.util.Date;
import org.bson.Document;
import ch.qos.logback.classic.spi.ILoggingEvent;


public class MongoDBAppender extends MongoDBAppenderBase<ILoggingEvent>{

	/**运行时间*/
	private static final String RUNNING_DATE="ruda";
	/**日志等级*/
	private static final String LOG_LEVEL="lole";
	/**访问包名*/
	private static final String PACKAGE_NAME="pana";
	/**日志ID*/
	private static final String LOG_ID="loID";
	/**日志内容*/
	private static final String LOG_CONTENT="loco";
	/**日志参数*/
	private static final String LOG_PAPAMETER="lopa";
	/**终端地址*/
	private static final String SOURCE_ADDRESS="soad";
	/**访问服务地址*/
	private static final String DESTINATION_ADDRESS="dead";
	@Override
	protected Document toMongoDocument(ILoggingEvent event) {
		// TODO Auto-generated method stub
		Document document=new Document();
		
		document.append(RUNNING_DATE, new Date(event.getTimeStamp()));
		document.append(LOG_LEVEL, event.getLevel().toString());
		String name=event.getCallerData()[0].getClassName();
		int flag=name.lastIndexOf(".");
		String packageName=name.substring(0, flag);
		String fid=name.substring(flag+1, name.length());
		String bid=packageName.substring(packageName.lastIndexOf(".")+1, packageName.length());
		if("vrmt".equals(bid)){
			bid="BS100";
		}else if("am".equals(bid)){
			bid="BS011";
		}else if("dm".equals(bid)){
			bid="BS010";
		}else if("wm".equals(bid)){
			bid="BS101";
		}else{
			return null;
		}
		document.append(PACKAGE_NAME, packageName);
		document.append(LOG_ID,bid+fid);
		document.append(LOG_CONTENT, event.getMessage());
		document.append(LOG_PAPAMETER,"");
		document.append(SOURCE_ADDRESS, "");
		document.append(DESTINATION_ADDRESS, "");
		
		
		return document;
	}

}
