package xml.config;

import java.util.List;

public class BlankDiscNew implements CompactDisc{
	
	private String title;
	private String artist;
	private List<String> tracks;

	public BlankDiscNew(String title,String artist,List<String> tracks) {
		// TODO Auto-generated constructor stub
		this.artist=artist;
		this.title=title;
		this.tracks=tracks;
	}
	
	public void play() {
		// TODO Auto-generated method stub
		System.out.println("Playing "+title+" by "+artist);
		for(String str:tracks){
			System.out.println(str);
		}
	}

}
