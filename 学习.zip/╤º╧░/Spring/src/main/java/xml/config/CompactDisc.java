package xml.config;

public interface CompactDisc {
	
	public void play();

}
