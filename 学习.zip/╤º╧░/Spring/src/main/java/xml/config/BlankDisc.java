package xml.config;

public class BlankDisc implements CompactDisc{
	
	private String title;
	private String artist;

	public BlankDisc(String title,String artist) {
		// TODO Auto-generated constructor stub
		this.artist=artist;
		this.title=title;
	}
	
	public void play() {
		// TODO Auto-generated method stub
		System.out.println("Playing "+title+" by "+artist);
	}

}
