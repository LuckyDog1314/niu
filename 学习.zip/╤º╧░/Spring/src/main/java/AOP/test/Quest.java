package AOP.test;

public interface Quest {

	public void embark();
}
