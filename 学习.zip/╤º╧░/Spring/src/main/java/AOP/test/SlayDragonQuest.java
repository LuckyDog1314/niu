package AOP.test;

import java.io.PrintStream;

public class SlayDragonQuest implements Quest {

	private PrintStream stream;
	
	public SlayDragonQuest(PrintStream stream) {
		this.stream=stream;
	}

	public void embark() {
		stream.println("啦啦啦，德玛西亚");
	}

}
