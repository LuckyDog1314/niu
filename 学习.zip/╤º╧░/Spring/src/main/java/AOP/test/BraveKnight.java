package AOP.test;
/**
 * 构造器注入
 * @author niushunyuan
 *
 */
public class BraveKnight implements Knight {

//	private Quest quest;
//	private Minstrel minstrel;
//	
//	public BraveKnight(Quest quest,Minstrel minstrel) {   //<--Quest被注入进来
//		this.quest=quest;
//		this.minstrel=minstrel;
//	}
//	
//	public void embarkOnQuest(){
//		minstrel.singBeforeQuest();
//		quest.embark();
//		minstrel.singAfterQuest();
//	}
	private Quest quest;
	
	public BraveKnight(Quest quest) {   //<--Quest被注入进来
		this.quest=quest;
	}
	
	public void embarkOnQuest(){
		quest.embark();
	}
}
