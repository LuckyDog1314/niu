package AOP.test;

public interface Knight {
	public void embarkOnQuest();
}
