package java.config;

public interface CompactDisc {
	
	public void play();

}
