package java.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class CDPlayerCofig {

	//声明简单的Bean
	@Bean
	public CompactDisc sgtPeppers(){
		return new SgtPeppers();
	}
	//借助JavaConfig实现注入
	@Bean
	public CDPlayer cdPlayer(){
		return new CDPlayer(sgtPeppers());
	}
	//使用CDPlayer的构造器实现了DI功能
//	@Bean
//	public CDPlayer cdPlayer(CompactDisc compactDisc){
//		return new CDPlayer(compactDisc);
//	}
	//通过Setter方法注入CompactDisc
	@Bean
	public CDPlayer cdPlayer(CompactDisc compactDisc){
		CDPlayer cdplayer=new CDPlayer(compactDisc);
		cdplayer.setCd(compactDisc);
		return cdplayer;
	}
}
