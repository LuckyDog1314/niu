package java.config;

public interface MediaPlayer{

	public void play();
	
}
