package custom.annotation;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component
@Cold2
public class B implements A{

	public void play() {
		// TODO Auto-generated method stub
		System.out.println("BBBBBBBBBBBBBBBB");
	}

}
