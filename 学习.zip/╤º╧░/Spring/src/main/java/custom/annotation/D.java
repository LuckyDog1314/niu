package custom.annotation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class D {

	private A a;
	
	@Autowired
	@Cold
	public void setB(A a){
		this.a =a;
	}
	public A getA() {
		return a;
	}
}
