package custom.annotation;

import org.springframework.stereotype.Component;

public class C implements A{

	public void play() {
		// TODO Auto-generated method stub
		System.out.println("CCCCCCCCCCCCCCCCCCCCC");
	}

}
