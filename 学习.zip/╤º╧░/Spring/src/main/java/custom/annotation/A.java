package custom.annotation;

public interface A {

	public void play();
}
