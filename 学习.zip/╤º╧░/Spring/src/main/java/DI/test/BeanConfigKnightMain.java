package DI.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * 启用Java配置
 * @author niushunyuan
 *
 */
@Configuration
public class BeanConfigKnightMain {

	@Bean
	public Knight knight(){
		return new BraveKnight(quest());
	}
	
	@Bean
	public Quest quest(){
		return new SlayDragonQuest(System.out);
	}
	
	public static void main(String[] args) {
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext(BeanConfigKnightMain.class);
		Knight knight=context.getBean(Knight.class);
		knight.embarkOnQuest();
	}
}
