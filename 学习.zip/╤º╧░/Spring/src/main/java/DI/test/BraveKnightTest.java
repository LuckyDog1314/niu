package DI.test;

import org.junit.Test;
import org.mockito.Mockito;

public class BraveKnightTest {
	
	@Test
	public void Test(){
		 Quest mockQuest=Mockito.mock(Quest.class);
		 BraveKnight braveKnight=new BraveKnight(mockQuest);
		 braveKnight.embarkOnQuest();
		 //验证Quest接口中embark()方法运行一次
		 Mockito.verify(mockQuest,Mockito.times(1)).embark();
	}

}
