package DI.test;

import org.springframework.context.support.FileSystemXmlApplicationContext;
/**
 * Spring初始化容器.三种经常用到的实现：

一、ClassPathXmlApplicationContext:从类路径中加载。

二、FileSystemXmlApplicationContext:从文件系统加载。

三、XmlWebApplicationContext:从web系统中加载。
 * @author niushunyuan
 *
 */
public class XmlConfigKnightMain {
	
	public static void main(String[] args) throws Exception{
		FileSystemXmlApplicationContext context=new FileSystemXmlApplicationContext("D:/EclipseWorkSpace/Spring/config/DItest.xml");
		Knight knight=context.getBean(Knight.class);
		knight.embarkOnQuest();
	}

}
