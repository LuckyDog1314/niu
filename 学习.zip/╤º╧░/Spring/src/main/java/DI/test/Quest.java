package DI.test;

public interface Quest {

	public void embark();
}
