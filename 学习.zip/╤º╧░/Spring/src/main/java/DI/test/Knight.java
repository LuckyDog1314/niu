package DI.test;

public interface Knight {
	public void embarkOnQuest();
}
