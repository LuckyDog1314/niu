package autowiring.test1;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import DI.test.SlayDragonQuest;

@Configuration
//@ComponentScan(basePackages={"autowiring.test1","DI.test"})
@ComponentScan(basePackageClasses={CompactDisc.class,SlayDragonQuest.class})
public class CDPlayerConfig {

}
