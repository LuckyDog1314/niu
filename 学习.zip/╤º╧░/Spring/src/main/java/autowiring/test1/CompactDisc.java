package autowiring.test1;

public interface CompactDisc {
	
	public void play();

}
