package autowiring.test2;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
//@ComponentScan(basePackages={"autowiring.test1","DI.test"})
@ComponentScan(basePackageClasses={CDPlayer.class})
public class CDPlayerConfig2 {

}
