package autowiring.test2;

import org.springframework.stereotype.Component;

@Component
public class SgtPeppers2 implements CompactDisc {

	private String title = "自动化装配Bean";
	private String artist = "<<<<<<>>>>>>案例1";

	public void play() {
		// TODO Auto-generated method stub
		System.out.println(title + artist);
	}

}
