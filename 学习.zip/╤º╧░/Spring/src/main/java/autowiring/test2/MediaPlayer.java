package autowiring.test2;

public interface MediaPlayer{

	public void play();
	
}
