package autowiring.test2;

public interface CompactDisc {
	
	public void play();

}
