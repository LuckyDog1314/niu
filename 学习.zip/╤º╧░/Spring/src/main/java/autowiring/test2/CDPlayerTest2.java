package autowiring.test2;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration(locations={"file:D:/EclipseWorkSpace/Spring/config/autowiringtest1.xml"})
@ContextConfiguration(classes=CDPlayerConfig2.class)
public class CDPlayerTest2 {

	@Autowired
	private MediaPlayer player;
	
	@Autowired
	private CompactDisc cd;
	
	@Test
	public void cdShouldNotBeNull(){
		Assert.assertNotNull(cd);//验证入力对象不为空
	}
}
