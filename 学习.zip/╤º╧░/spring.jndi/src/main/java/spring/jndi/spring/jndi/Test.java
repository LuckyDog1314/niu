package spring.jndi.spring.jndi;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jndi.JndiObjectFactoryBean;
import org.springframework.jndi.JndiTemplate;

public class Test {
	public static void main(String[] args) throws NamingException {
	    JndiTemplate jndiTemplate = new JndiTemplate();
	    DataSource dataSource =(DataSource) jndiTemplate.lookup("java:comp/env/jdbc/UsersDB");
	  
	}
}
