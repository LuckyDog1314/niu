package cn.sh.changxing.bs.log.collection;

import org.bson.Document;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import ch.qos.logback.core.UnsynchronizedAppenderBase;

public abstract class MongoDBAppenderBase<E> extends UnsynchronizedAppenderBase<E> {

	private static MongoCollection<Document> doc;
	private MongoClient mongoClient;
	private MongoClientURI uri;
	private MongoDatabase database;

	@Override
	public void start() {
		// TODO Auto-generated method stub
		uri = new MongoClientURI("mongodb://vrmt:abc.123@192.168.30.234:27017/admin");
		mongoClient = new MongoClient(uri);
		database = mongoClient.getDatabase("vrmt");
		doc = database.getCollection("running_log");
		doc.insertOne(new Document("message", "启动日志收集功能"));
		System.out.println("连接数据库"+doc);
		super.start();
	}

	protected abstract Document toMongoDocument(E event);

	@Override
	protected void append(E eventObject) {
		// TODO Auto-generated method stub
		System.out.println(toMongoDocument(eventObject));
		doc.insertOne(toMongoDocument(eventObject));
		System.out.println(eventObject+"..............................");
	}

	@Override
	public void stop() {
		// TODO Auto-generated method stub
		if (mongoClient != null) {
			System.out.println("关闭数据库");
			mongoClient.close();
		}
		super.stop();
	}

}
