package cn.sh.changxing.bs.log.collection;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LogCollection {
	
	public void test(){
		Logger LOG=LoggerFactory.getLogger(LogCollection.class);
		LOG.error("hello");
	}
	
	public void test2(){
		Logger LOG=LoggerFactory.getLogger(LogCollection.class);
		LOG.info("错了");
	}
	
	public static void main(String[] args) {
		LogCollection lc=new LogCollection();
		lc.test();
		lc.test2();
	}

}
