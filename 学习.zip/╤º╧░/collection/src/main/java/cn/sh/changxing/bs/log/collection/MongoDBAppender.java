package cn.sh.changxing.bs.log.collection;

import org.bson.Document;
import ch.qos.logback.classic.spi.ILoggingEvent;

public class MongoDBAppender extends MongoDBAppenderBase<ILoggingEvent>{

	@Override
	protected Document toMongoDocument(ILoggingEvent event) {
		// TODO Auto-generated method stub
		Document document=new Document();
	    document.append("message", event.getMessage());
		return document;
	}
	
}
