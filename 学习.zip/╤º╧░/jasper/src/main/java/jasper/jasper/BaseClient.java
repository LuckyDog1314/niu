package jasper.jasper;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.UnsupportedCallbackException;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import com.sun.xml.wss.ProcessingContext;
import com.sun.xml.wss.XWSSProcessor;
import com.sun.xml.wss.XWSSProcessorFactory;
import com.sun.xml.wss.XWSSecurityException;
import com.sun.xml.wss.impl.callback.PasswordCallback;
import com.sun.xml.wss.impl.callback.UsernameCallback;

/**
 * API访问模板代码
 * 
 * @author niushunyuan
 *
 */
public abstract class BaseClient {
	protected static final String NAMESPACE_URI = "http://api.jasperwireless.com/ws/schema";
	protected static final String PREFIX = "jws";
	protected SOAPConnectionFactory connectionFactory;
	protected MessageFactory messageFactory;
	protected URL url;
	protected String licenseKey;

	protected XWSSProcessorFactory processorFactory;

	/**
	 * Constructor which initializes Soap Connection, messagefactory and
	 * ProcessorFactory
	 *
	 * @param url
	 * @throws SOAPException
	 * @throws MalformedURLException
	 * @throws XWSSecurityException
	 */
	public BaseClient(String url, String licenseKey) throws SOAPException, MalformedURLException, XWSSecurityException {
		connectionFactory = SOAPConnectionFactory.newInstance();
		messageFactory = MessageFactory.newInstance();
		processorFactory = XWSSProcessorFactory.newInstance();
		this.url = new URL(url);
		this.licenseKey = licenseKey;
	}

	/**
	 * 创建SOAP请求
	 * 
	 * @return
	 * @throws SOAPException
	 */
	protected SOAPMessage createRequest() throws SOAPException {
		return null;
	}

	/**
	 * 发送SOAP请求并得到应答
	 * 
	 * @throws SOAPException
	 * @throws IOException
	 * @throws XWSSecurityException
	 * @throws Exception
	 */
	public void callWebService(String username, String password)
			throws SOAPException, IOException, XWSSecurityException, Exception {
	}

	/**
	 * 解析SAOP请求
	 * 
	 * @param message
	 * @throws SOAPException
	 */
	abstract void writeResponse(SOAPMessage message) throws SOAPException;

	/**
	 * This method is used to add the security. This uses xwss:UsernameToken
	 * configuration and expects Username and Password to be passes.
	 * SecurityPolicy.xml file should be in classpath.
	 *
	 * @param message
	 * @param username
	 * @param password
	 * @return
	 * @throws IOException
	 * @throws XWSSecurityException
	 */
	protected SOAPMessage secureMessage(SOAPMessage message, final String username, final String password)
			throws IOException, XWSSecurityException {
		CallbackHandler callbackHandler = new CallbackHandler() {
			public void handle(Callback[] callbacks) throws UnsupportedCallbackException {
				for (int i = 0; i < callbacks.length; i++) {
					if (callbacks[i] instanceof UsernameCallback) {
						UsernameCallback callback = (UsernameCallback) callbacks[i];
						callback.setUsername(username);
					} else if (callbacks[i] instanceof PasswordCallback) {
						PasswordCallback callback = (PasswordCallback) callbacks[i];
						callback.setPassword(password);
					} else {
						throw new UnsupportedCallbackException(callbacks[i]);
					}
				}
			}
		};
		InputStream policyStream = null;
		XWSSProcessor processor = null;
		try {
			policyStream = getClass().getResourceAsStream("securityPolicy.xml");
			processor = processorFactory.createProcessorForSecurityConfiguration(policyStream, callbackHandler);
		} finally {
			if (policyStream != null) {
				policyStream.close();
			}
		}
		ProcessingContext context = processor.createProcessingContext(message);
		return processor.secureOutboundMessage(context);
	}
}
