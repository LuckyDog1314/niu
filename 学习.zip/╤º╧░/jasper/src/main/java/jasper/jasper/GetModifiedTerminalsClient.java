package jasper.jasper;

import java.io.IOException;
import java.net.MalformedURLException;

import javax.xml.soap.Name;
import javax.xml.soap.SOAPBodyElement;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPFault;
import javax.xml.soap.SOAPMessage;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.sun.xml.wss.XWSSecurityException;

/**
 * 返回自给定日期和时间以后已发生修改的所有设 备的ICCID 列表。
 * 
 * 要获得所有设备的列表，只 需忽略“since”参数。
 * 
 * @author niushunyuan
 *
 */
public class GetModifiedTerminalsClient extends BaseClient {

	public GetModifiedTerminalsClient(String url, String licenseKey)
			throws SOAPException, MalformedURLException, XWSSecurityException {
		super(url, licenseKey);
		// TODO Auto-generated constructor stub
	}

	@Override
	protected SOAPMessage createRequest() throws SOAPException {
		SOAPMessage message = messageFactory.createMessage();
		message.getMimeHeaders().addHeader("SOAPAction",
				"http://api.jasperwireless.com/ws/service/terminal/GetModifiedTerminals");
		SOAPEnvelope envelope = message.getSOAPPart().getEnvelope();
		Name terminalRequestName = envelope.createName("GetModifiedTerminalsRequest", PREFIX, NAMESPACE_URI);
		SOAPBodyElement terminalRequestElement = message.getSOAPBody().addBodyElement(terminalRequestName);
		Name msgId = envelope.createName("messageId", PREFIX, NAMESPACE_URI);
		SOAPElement msgElement = terminalRequestElement.addChildElement(msgId);
		msgElement.setValue("TCE-100-ABC-34084");
		Name version = envelope.createName("version", PREFIX, NAMESPACE_URI);
		SOAPElement versionElement = terminalRequestElement.addChildElement(version);
		versionElement.setValue("1.0");
		Name license = envelope.createName("licenseKey", PREFIX, NAMESPACE_URI);
		SOAPElement licenseElement = terminalRequestElement.addChildElement(license);
		licenseElement.setValue(licenseKey);
		// Name since = envelope.createName("since", PREFIX, NAMESPACE_URI);
		// SOAPElement sinceElement =
		// terminalRequestElement.addChildElement(since);
		// sinceElement.setValue("2017-01-10T09:12:00");
		return message;
	}

	public void callWebService(String username, String password)
			throws SOAPException, IOException, XWSSecurityException, Exception {
		SOAPMessage request = createRequest();
		request = secureMessage(request, username, password);
		// System.out.println("Request: ");
		// request.writeTo(System.out);
		// System.out.println("");
		SOAPConnection connection = connectionFactory.createConnection();
		SOAPMessage response = connection.call(request, url);
		// System.out.println("Response: ");
		// response.writeTo(System.out);
		// System.out.println("");
		if (!response.getSOAPBody().hasFault()) {
			writeResponse(response);
		} else {
			SOAPFault fault = response.getSOAPBody().getFault();
			System.err.println("Received SOAP Fault" + "11111111111111111111111111111111111111");
			System.err.println("SOAP Fault Code :" + fault.getFaultCode());
			System.err.println("SOAP Fault String :" + fault.getFaultString());
		}
	}

	@Override
	void writeResponse(SOAPMessage message) throws SOAPException {
		SOAPEnvelope envelope = message.getSOAPPart().getEnvelope();
		Name terminalResponseName = envelope.createName("GetModifiedTerminalsResponse", PREFIX, NAMESPACE_URI);
		SOAPBodyElement terminalResponseElement = (SOAPBodyElement) message.getSOAPBody()
				.getChildElements(terminalResponseName).next();
		Name terminals = envelope.createName("iccids", PREFIX, NAMESPACE_URI);
		SOAPBodyElement terminalElement = (SOAPBodyElement) terminalResponseElement.getChildElements(terminals).next();
		NodeList list = terminalElement.getChildNodes();
		Node n = null;
		for (int i = 0; i < list.getLength(); i++) {
			n = list.item(i);
			if (n.getLocalName() != null && !"null".equals(n.getLocalName()))
				System.out.println(n.getLocalName() + "  is " + n.getTextContent());

		}

		if (list == null || list.getLength() == 0) {
			System.out.println("No session found for ICCID ");
		}

	}

}
