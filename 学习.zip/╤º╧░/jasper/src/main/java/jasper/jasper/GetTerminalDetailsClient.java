package jasper.jasper;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.Iterator;
import java.util.List;
import javax.xml.soap.*;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import com.sun.xml.wss.XWSSecurityException;

/**
 * 返回关于列表中每个设备的详细信息。
 * 
 * @author niushunyuan
 *
 */
public class GetTerminalDetailsClient extends BaseClient {

	public GetTerminalDetailsClient(String url, String licenseKey)
			throws SOAPException, MalformedURLException, XWSSecurityException {
		super(url, licenseKey);
		// TODO Auto-generated constructor stub
	}

	protected SOAPMessage createRequest(List<String> iccidList) throws SOAPException {
		SOAPMessage message = messageFactory.createMessage();
		message.getMimeHeaders().addHeader("SOAPAction",
				"http://api.jasperwireless.com/ws/service/terminal/GetTerminalDetails");
		SOAPEnvelope envelope = message.getSOAPPart().getEnvelope();
		Name terminalRequestName = envelope.createName("GetTerminalDetailsRequest", PREFIX, NAMESPACE_URI);
		SOAPBodyElement terminalRequestElement = message.getSOAPBody().addBodyElement(terminalRequestName);
		Name msgId = envelope.createName("messageId", PREFIX, NAMESPACE_URI);
		SOAPElement msgElement = terminalRequestElement.addChildElement(msgId);
		msgElement.setValue("TCE-100-ABC-34084");
		Name version = envelope.createName("version", PREFIX, NAMESPACE_URI);
		SOAPElement versionElement = terminalRequestElement.addChildElement(version);
		versionElement.setValue("1.0");
		Name license = envelope.createName("licenseKey", PREFIX, NAMESPACE_URI);
		SOAPElement licenseElement = terminalRequestElement.addChildElement(license);
		licenseElement.setValue(licenseKey);
		Name iccids = envelope.createName("iccids", PREFIX, NAMESPACE_URI);
		SOAPElement iccidsElement = terminalRequestElement.addChildElement(iccids);
		for (int i = 0; i < iccidList.size(); i++) {
			Name iccidName = envelope.createName("iccid", PREFIX, NAMESPACE_URI);
			SOAPElement iccidElement = iccidsElement.addChildElement(iccidName);
			iccidElement.setValue(iccidList.get(i));
		}
		return message;
	}

	public void callWebService(String username, String password, List<String> iccidList)
			throws SOAPException, IOException, XWSSecurityException, Exception {
		SOAPMessage request = createRequest(iccidList);
		request = secureMessage(request, username, password);
		SOAPConnection connection = connectionFactory.createConnection();
		SOAPMessage response = connection.call(request, url);
		if (!response.getSOAPBody().hasFault()) {
			writeResponse(response);
		} else {
			SOAPFault fault = response.getSOAPBody().getFault();
			System.err.println("Received SOAP Fault");
			System.err.println("SOAP Fault Code :" + fault.getFaultCode());
			System.err.println("SOAP Fault String :" + fault.getFaultString());
		}
	}

	@Override
	void writeResponse(SOAPMessage message) throws SOAPException {
		// TODO Auto-generated method stub
		SOAPEnvelope envelope = message.getSOAPPart().getEnvelope();
		Name terminalResponseName = envelope.createName("GetTerminalDetailsResponse", PREFIX, NAMESPACE_URI);
		SOAPBodyElement terminalResponseElement = (SOAPBodyElement) message.getSOAPBody()
				.getChildElements(terminalResponseName).next();
		Name terminals = envelope.createName("terminals", PREFIX, NAMESPACE_URI);
		Name terminal = envelope.createName("terminal", PREFIX, NAMESPACE_URI);
		SOAPBodyElement terminalsElement = (SOAPBodyElement) terminalResponseElement.getChildElements(terminals).next();
		@SuppressWarnings("unchecked")
		Iterator<SOAPBodyElement> iterator = (Iterator<SOAPBodyElement>) terminalsElement.getChildElements(terminal);
		while (iterator.hasNext()) {
			SOAPBodyElement terminalElement = (SOAPBodyElement) iterator.next();
			NodeList list = terminalElement.getChildNodes();
			Node n = null;
			for (int i = 0; i < list.getLength(); i++) {
				n = list.item(i);
				// if ("iccid".equalsIgnoreCase(n.getLocalName())) {
				// System.out.print("设备" + n.getTextContent() + "的SIM卡状态为：");
				// }
				// if ("status".equalsIgnoreCase(n.getLocalName())) {
				// System.out.println(n.getTextContent() + ";");
				// }
				// if ("monthToDateUsage".equalsIgnoreCase(n.getLocalName())) {
				// System.out.println("当月流量为：" + n.getTextContent() + ";");
				// }
				// if ("dateActivated".equalsIgnoreCase(n.getLocalName())) {
				// System.out.println("激活时间为：" + n.getTextContent() + ";");
				// }
				// if ("dateAdded".equalsIgnoreCase(n.getLocalName())) {
				// System.out.println("添加日期为：" + n.getTextContent() + ";");
				// }
				if ("iccid".equalsIgnoreCase(n.getLocalName())) {
					System.out.println("iccid为：" + n.getTextContent() + ";");
				}
				if ("terminalId".equalsIgnoreCase(n.getLocalName())) {
					System.out.println("terminalId为：" + n.getTextContent() + ";");
				}
				if ("modemId".equalsIgnoreCase(n.getLocalName())) {
					System.out.println("modemId为：" + n.getTextContent() + ";");
				}
				if ("customer".equalsIgnoreCase(n.getLocalName())) {
					System.out.println("customer为：" + n.getTextContent() + ";");
				}
				if ("endConsumerId".equalsIgnoreCase(n.getLocalName())) {
					System.out.println("endConsumerId为：" + n.getTextContent() + ";");
				}
				if ("suspended".equalsIgnoreCase(n.getLocalName())) {
					System.out.println("suspended为：" + n.getTextContent() + ";");
				}
				if ("ratePlan".equalsIgnoreCase(n.getLocalName())) {
					System.out.println("ratePlan为：" + n.getTextContent() + ";");
				}
				if ("status".equalsIgnoreCase(n.getLocalName())) {
					System.out.println("status为：" + n.getTextContent() + ";");
				}
				if ("monthToDateUsage".equalsIgnoreCase(n.getLocalName())) {
					System.out.println("monthToDateUsage为：" + n.getTextContent() + ";");
				}
				if ("overageLimitReached".equalsIgnoreCase(n.getLocalName())) {
					System.out.println("overageLimitReached为：" + n.getTextContent() + ";");
				}
				if ("overageLimitOverride".equalsIgnoreCase(n.getLocalName())) {
					System.out.println("overageLimitOverride为：" + n.getTextContent() + ";");
				}
				if ("dateActivated".equalsIgnoreCase(n.getLocalName())) {
					System.out.println("dateActivated为：" + n.getTextContent() + ";");
				}
				if ("dateAdded".equalsIgnoreCase(n.getLocalName())) {
					System.out.println("dateAdded为：" + n.getTextContent() + ";");
				}
				if ("dateModified".equalsIgnoreCase(n.getLocalName())) {
					System.out.println("dateModified为：" + n.getTextContent() + ";");
				}
				if ("dateShipped".equalsIgnoreCase(n.getLocalName())) {
					System.out.println("dateShipped为：" + n.getTextContent() + ";");
				}
				if ("monthToDateDataUsage".equalsIgnoreCase(n.getLocalName())) {
					System.out.println("monthToDateDataUsage为：" + n.getTextContent() + ";");
				}
				if ("monthToDateSMSUsage".equalsIgnoreCase(n.getLocalName())) {
					System.out.println("monthToDateSMSUsage为：" + n.getTextContent() + ";");
				}
				if ("monthToDateVoiceUsage".equalsIgnoreCase(n.getLocalName())) {
					System.out.println("monthToDateVoiceUsage为：" + n.getTextContent() + ";");
				}
				if ("secureSimId".equalsIgnoreCase(n.getLocalName())) {
					System.out.println("secureSimId为：" + n.getTextContent() + ";");
				}
				if ("rating".equalsIgnoreCase(n.getLocalName())) {
					// System.out.println("rating为：" + n.getTextContent() +
					// ";");
					NodeList rating = n.getChildNodes();
					Node ra = null;
					for (int j = 0; j < rating.getLength(); j++) {
						ra = rating.item(j);
						if ("termStartDate".equalsIgnoreCase(ra.getLocalName())) {
							System.out.println("termStartDate为：" + ra.getTextContent() + ";");
						}
						if ("termEndDate".equalsIgnoreCase(ra.getLocalName())) {
							System.out.println("termEndDate为：" + ra.getTextContent() + ";");
						}
						if ("renewalPolicy".equalsIgnoreCase(ra.getLocalName())) {
							System.out.println("renewalPolicy为：" + ra.getTextContent() + ";");
						}
						if ("renewalRatePlan".equalsIgnoreCase(ra.getLocalName())) {
							System.out.println("renewalRatePlan为：" + ra.getTextContent() + ";");
						}
						if ("totalPrimaryIncludedData".equalsIgnoreCase(ra.getLocalName())) {
							System.out.println("totalPrimaryIncludedData为：" + ra.getTextContent() + ";");
						}
						if ("primaryDataRemaining".equalsIgnoreCase(ra.getLocalName())) {
							System.out.println("primaryDataRemaining为：" + ra.getTextContent() + ";");
						}
						if ("totalPrimaryIncludedSMS".equalsIgnoreCase(ra.getLocalName())) {
							System.out.println("totalPrimaryIncludedSMS为：" + ra.getTextContent() + ";");
						}
						if ("primarySMSRemaining".equalsIgnoreCase(ra.getLocalName())) {
							System.out.println("primarySMSRemaining为：" + ra.getTextContent() + ";");
						}
					}
				}
				if ("secureSimUsernameCopyRule".equalsIgnoreCase(n.getLocalName())) {
					System.out.println("secureSimUsernameCopyRule为：" + n.getTextContent() + ";");
				}
				if ("secureSimPasswordCopyRule".equalsIgnoreCase(n.getLocalName())) {
					System.out.println("secureSimPasswordCopyRule为：" + n.getTextContent() + ";");
				}
				if ("accountId".equalsIgnoreCase(n.getLocalName())) {
					System.out.println("accountId为：" + n.getTextContent() + ";");
				}
				if ("fixedIpAddress".equalsIgnoreCase(n.getLocalName())) {
					System.out.println("fixedIpAddress为：" + n.getTextContent() + ";");
				}
				if ("ctdSessionCount".equalsIgnoreCase(n.getLocalName())) {
					System.out.println("ctdSessionCount为：" + n.getTextContent() + ";");
				}
				if ("imsi".equalsIgnoreCase(n.getLocalName())) {
					System.out.println("imsi为：" + n.getTextContent() + ";");
				}
				if ("primaryICCID".equalsIgnoreCase(n.getLocalName())) {
					System.out.println("primaryICCID为：" + n.getTextContent() + ";");
				}
				if ("imei".equalsIgnoreCase(n.getLocalName())) {
					System.out.println("imei为：" + n.getTextContent() + ";");
				}
				if ("globalSimType".equalsIgnoreCase(n.getLocalName())) {
					System.out.println("globalSimType为：" + n.getTextContent() + ";");
				}
				if ("simNotes".equalsIgnoreCase(n.getLocalName())) {
					System.out.println("simNotes为：" + n.getTextContent() + ";");
				}
				if ("version".equalsIgnoreCase(n.getLocalName())) {
					System.out.println("version为：" + n.getTextContent() + ";");
				}

			}
		}

		// System.out.println("Terminal Response [" + terminalValue + "]");

	}
}
