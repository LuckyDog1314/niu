package jasper.jasper;

public class M2MFactory {
	public static <T extends BaseClient> BaseClient getClient(Class<T> T) {

		return null;
	};
}
