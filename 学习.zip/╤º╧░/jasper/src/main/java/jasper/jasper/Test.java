package jasper.jasper;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.soap.SOAPException;

import com.sun.xml.wss.XWSSecurityException;

public class Test {

	public static void main(String[] args) {
		String url = "https://api.10646.cn/ws/service/terminal";
		String licenseKey = "dca92d1b-c1a1-4bd6-a94d-1a36112147b8";
		String username = "wangcw";
		String password = "Wang1234";
		// String url = "https://api.10646.cn/ws/service/billing";
		// String licenseKey = "6247e65f-3f4f-4b68-beab-2f2547edf8cb";
		// String username = "nicaiying";
		// String password = "cx.2017";

		List<String> iccidList = new ArrayList<String>();
		iccidList.add("89860616010053864605");
//		 iccidList.add("89860616010053864613");
//		 iccidList.add("89860616010053864621");
		//String iccid = "89860616010053864605";
		try {
			 GetTerminalDetailsClient gtdc = new GetTerminalDetailsClient(url,
			 licenseKey);
			 gtdc.callWebService(username, password, iccidList);
//			 GetModifiedTerminalsClient gtc = new
//			 GetModifiedTerminalsClient(url, licenseKey);
//			 gtc.callWebService(username, password);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SOAPException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (XWSSecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// try {
		// GetInvoiceClient gic = new GetInvoiceClient(url, licenseKey);
		// gic.callWebService(username, password, "123");
		// } catch (MalformedURLException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// } catch (SOAPException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// } catch (XWSSecurityException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// } catch (IOException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// } catch (Exception e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }
		//
		// try {
		// GetModifiedTerminalsClient gtc = new GetModifiedTerminalsClient(url,
		// licenseKey);
		// gtc.callWebService(username, password);
		// } catch (MalformedURLException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// } catch (SOAPException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// } catch (XWSSecurityException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// } catch (IOException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// } catch (Exception e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }

	}

}
