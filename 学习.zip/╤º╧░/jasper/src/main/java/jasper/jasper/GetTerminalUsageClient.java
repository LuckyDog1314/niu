package jasper.jasper;

import java.io.IOException;
import java.net.MalformedURLException;

import javax.xml.soap.Name;
import javax.xml.soap.SOAPBodyElement;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPFault;
import javax.xml.soap.SOAPMessage;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.sun.xml.wss.XWSSecurityException;

public class GetTerminalUsageClient extends BaseClient {

	public GetTerminalUsageClient(String url, String licenseKey)
			throws SOAPException, MalformedURLException, XWSSecurityException {
		super(url, licenseKey);
		// TODO Auto-generated constructor stub
	}

	protected SOAPMessage createRequest(String iccid) throws SOAPException {
		SOAPMessage message = messageFactory.createMessage();
		message.getMimeHeaders().addHeader("SOAPAction",
				"http://api.jasperwireless.com/ws/service/billing/GetTerminalUsage");
		SOAPEnvelope envelope = message.getSOAPPart().getEnvelope();
		Name terminalRequestName = envelope.createName("GetTerminalUsageRequest", PREFIX, NAMESPACE_URI);
		SOAPBodyElement terminalRequestElement = message.getSOAPBody().addBodyElement(terminalRequestName);
		Name msgId = envelope.createName("messageId", PREFIX, NAMESPACE_URI);
		SOAPElement msgElement = terminalRequestElement.addChildElement(msgId);
		msgElement.setValue("TCE-100-ABC-34084");
		Name version = envelope.createName("version", PREFIX, NAMESPACE_URI);
		SOAPElement versionElement = terminalRequestElement.addChildElement(version);
		versionElement.setValue("1.0");
		Name license = envelope.createName("licenseKey", PREFIX, NAMESPACE_URI);
		SOAPElement licenseElement = terminalRequestElement.addChildElement(license);
		licenseElement.setValue(licenseKey);
		Name iccidName = envelope.createName("iccid", PREFIX, NAMESPACE_URI);
		SOAPElement iccidElement = terminalRequestElement.addChildElement(iccidName);
		iccidElement.setValue(iccid);
		return message;
	}

	public void callWebService(String username, String password, String iccid)
			throws SOAPException, IOException, XWSSecurityException, Exception {
		SOAPMessage request = createRequest(iccid);
		request = secureMessage(request, username, password);
		SOAPConnection connection = connectionFactory.createConnection();
		SOAPMessage response = connection.call(request, url);
		if (!response.getSOAPBody().hasFault()) {
			writeResponse(response);
		} else {
			SOAPFault fault = response.getSOAPBody().getFault();
			System.err.println("Received SOAP Fault");
			System.err.println("SOAP Fault Code :" + fault.getFaultCode());
			System.err.println("SOAP Fault String :" + fault.getFaultString());
		}
	}

	@Override
	void writeResponse(SOAPMessage message) throws SOAPException {
		// TODO Auto-generated method stub
		SOAPEnvelope envelope = message.getSOAPPart().getEnvelope();
		Name terminalResponseName = envelope.createName("GetTerminalUsageResponse", PREFIX, NAMESPACE_URI);
		SOAPBodyElement terminalResponseElement = (SOAPBodyElement) message.getSOAPBody()
				.getChildElements(terminalResponseName).next();
		// Name totalDataVolume = envelope.createName("totalDataVolume", PREFIX,
		// NAMESPACE_URI);
		// Name billableDataVolume = envelope.createName("billableDataVolume",
		// PREFIX, NAMESPACE_URI);
		// SOAPBodyElement totalDataVolumeElement = (SOAPBodyElement)
		// terminalResponseElement
		// .getChildElements(totalDataVolume).next();
		// SOAPBodyElement billableDataVolumeElement = (SOAPBodyElement)
		// terminalResponseElement
		// .getChildElements(billableDataVolume).next();
		NodeList list = terminalResponseElement.getChildNodes();
		Node n = null;
		
		for (int i = 0; i < list.getLength(); i++) {
			n = list.item(i);
			if ("iccid".equalsIgnoreCase(n.getLocalName())) {
				System.out.print("设备" + n.getTextContent());	
			}
			if ("totalDataVolume".equalsIgnoreCase(n.getLocalName())) {
				System.out.print("的总流量为：" + n.getTextContent() + ",");	
			}
			if ("billableDataVolume".equalsIgnoreCase(n.getLocalName())) {
				System.out.print("已使用流量为：" + n.getTextContent());	
			}
			
		}

		// System.out.println("Terminal Response [" + terminalValue + "]");

	}

}
