package jasper.jasper;

import java.io.IOException;
import java.net.MalformedURLException;

import javax.xml.soap.Name;
import javax.xml.soap.SOAPBodyElement;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPFault;
import javax.xml.soap.SOAPMessage;

import com.sun.xml.wss.XWSSecurityException;

/**
 * 账单：返回给定账户和计费周期的账单数据
 * 
 * @author niushunyuan
 *
 */
public class GetInvoiceClient extends BaseClient {

	public GetInvoiceClient(String url, String licenseKey)
			throws SOAPException, MalformedURLException, XWSSecurityException {
		super(url, licenseKey);
		// TODO Auto-generated constructor stub
	}

	private SOAPMessage createRequest(String accountId) throws SOAPException {
		SOAPMessage message = messageFactory.createMessage();
		message.getMimeHeaders().addHeader("SOAPAction", "http://api.jasperwireless.com/ws/service/billing/GetInvoice");
		SOAPEnvelope envelope = message.getSOAPPart().getEnvelope();
		Name terminalRequestName = envelope.createName("GetInvoiceRequest", PREFIX, NAMESPACE_URI);
		SOAPBodyElement terminalRequestElement = message.getSOAPBody().addBodyElement(terminalRequestName);
		Name msgId = envelope.createName("messageId", PREFIX, NAMESPACE_URI);
		SOAPElement msgElement = terminalRequestElement.addChildElement(msgId);
		msgElement.setValue("TCE-100-ABC-34084");
		Name version = envelope.createName("version", PREFIX, NAMESPACE_URI);
		SOAPElement versionElement = terminalRequestElement.addChildElement(version);
		versionElement.setValue("1.0");
		Name license = envelope.createName("licenseKey", PREFIX, NAMESPACE_URI);
		SOAPElement licenseElement = terminalRequestElement.addChildElement(license);
		licenseElement.setValue(licenseKey);
		Name accountid = envelope.createName("accountId", PREFIX, NAMESPACE_URI);
		SOAPElement accoutidElement = terminalRequestElement.addChildElement(accountid);
		accoutidElement.setValue(accountId);
		return message;
	}

	public void callWebService(String username, String password, String accountId)
			throws SOAPException, IOException, XWSSecurityException, Exception {
		SOAPMessage request = createRequest(accountId);
		request = secureMessage(request, username, password);
		// System.out.println("Request: ");
		// request.writeTo(System.out);
		// System.out.println("");
		SOAPConnection connection = connectionFactory.createConnection();
		SOAPMessage response = connection.call(request, url);
		// System.out.println("Response: ");
		// response.writeTo(System.out);
		// System.out.println("");
		if (!response.getSOAPBody().hasFault()) {
			writeResponse(response);
		} else {
			SOAPFault fault = response.getSOAPBody().getFault();
			System.err.println("Received SOAP Fault" + "11111111111111111111111111111111111111");
			System.err.println("SOAP Fault Code :" + fault.getFaultCode());
			System.err.println("SOAP Fault String :" + fault.getFaultString());
		}
	}

	@Override
	void writeResponse(SOAPMessage message) throws SOAPException {
		SOAPEnvelope envelope = message.getSOAPPart().getEnvelope();
		Name terminalResponseName = envelope.createName("GetInvoiceResponse", PREFIX, NAMESPACE_URI);
		SOAPBodyElement terminalResponseElement = (SOAPBodyElement) message.getSOAPBody()
				.getChildElements(terminalResponseName);
		Name accountId = envelope.createName("accountId", PREFIX, NAMESPACE_URI);
		SOAPBodyElement terminalsElement = (SOAPBodyElement) terminalResponseElement.getChildElements(accountId).next();
		System.out.println(terminalsElement.getTextContent());
	}

}
